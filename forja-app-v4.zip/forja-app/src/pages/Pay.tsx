import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { RippleButton, useAuth } from "@/components/Providers";
import { formatToman } from "@/lib/format";
import { buy, consume, isNativeAndroid } from "@/lib/myket";

type Init = { paymentId: number; amount: number; sku: string; payload: string; packageName: string; rsaPublicKey: string };

export default function PayPage() {
  const { user, loading, refresh } = useAuth();
  const router = useRouter();
  const [init, setInit] = useState<Init | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    void apiFetch("/api/payment/myket/init", { method: "POST" })
      .then((r) => r.json())
      .then((d) => (d.ok ? setInit(d as Init) : setError(d.error || "خطا در شروع پرداخت")));
  }, []);

  async function pay() {
    if (!init || busy) return;
    setError("");
    if (!isNativeAndroid()) {
      setError("پرداخت فقط داخل اپ نصب‌شده روی اندروید و با نصب بودن مایکت ممکن است.");
      return;
    }
    setBusy(true);
    try {
      const purchase = await buy(init.sku, init.payload, init.rsaPublicKey);
      if (!purchase.signatureVerified) throw new Error("امضای رسید مایکت معتبر نبود؛ اشتراک فعال نشد.");
      const res = await apiFetch("/api/payment/myket/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paymentId: init.paymentId, purchase }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || "تأیید ناموفق");
      if (purchase.purchaseToken) void consume(purchase.purchaseToken); // تا ماه بعد دوباره قابل خرید باشد
      await refresh();
      router.replace("/assess");
    } catch (e) {
      setError(e instanceof Error ? e.message : "پرداخت انجام نشد");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="px-5 pt-10">
      <button className="text-sm text-white/50" onClick={() => router.back()}>
        بازگشت
      </button>
      <div className="card mt-5 overflow-hidden">
        <div className="bg-[#0b1b12] p-5">
          <p className="text-xs text-[#9be15d]">پرداخت امن با مایکت</p>
          <h1 className="mt-2 text-2xl font-extrabold">اشتراک ماهانه فُرجا</h1>
        </div>
        <div className="p-5">
          {init ? (
            <>
              <Row k="محصول" v="اشتراک ماهانه" />
              <Row k="مبلغ" v={formatToman(init.amount)} />
              <Row k="مدت" v="۳۰ روز" />
            </>
          ) : (
            <p className="text-sm text-[var(--muted)]">در حال آماده‌سازی...</p>
          )}
          {error ? <p className="mt-3 text-sm text-[var(--danger)]">{error}</p> : null}
          <RippleButton className="btn-lime btn-full mt-5" disabled={!init || busy} onClick={pay}>
            {busy ? "در حال پرداخت..." : "پرداخت و فعال‌سازی اشتراک"}
          </RippleButton>
          <p className="mt-3 text-[11px] leading-6 text-white/40">اشتراک فقط بعد از پرداخت موفق در مایکت فعال می‌شود.</p>
          <p className="mt-2 text-[10px] text-white/25" dir="ltr">{init?.packageName} · {init?.sku} · {__BUILD__}</p>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between border-b border-white/5 py-2 text-xs">
      <span className="text-white/40">{k}</span>
      <span className="font-bold">{v}</span>
    </div>
  );
}
