import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { IMG } from "@/lib/media";
import { RippleButton } from "@/components/Providers";
import { useAuth } from "@/components/Providers";

const slides = [
  {
    img: IMG.hero,
    title: "بدن ساخته نمی‌شود. فورج می‌شود.",
    text: "مربی هوشمند فُرجا از روی قد، وزن، هدف و ضعف‌هات یه برنامه واقعی می‌چینه؛ نه یه جدول رندوم.",
  },
  {
    img: IMG.poseGym,
    title: "تمرین هر روز، داخل خود اپ",
    text: "ست بزن، استراحت کن، رد کن، تمام کن. پیشرفت و کالری و XP همین‌جا ثبت می‌شه.",
  },
  {
    img: IMG.womanSquat,
    title: "برنامه مخصوص بدن تو",
    text: "بالاتنه، پایین‌تنه یا کل بدن. باشگاه یا خانه. مربی مسیر ۴ هفته‌ای اختصاصی می‌سازه.",
  },
];

function markOnboarded() {
  try {
    localStorage.setItem("forja_onboard", "1");
  } catch {
    /* ignore */
  }
}

export default function SplashPage() {
  const router = useRouter();
  const { user, loading } = useAuth();
  const [phase, setPhase] = useState<"splash" | "onboard">("splash");
  const [i, setI] = useState(0);

  const [minDone, setMinDone] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setMinDone(true), 3600);
    return () => clearTimeout(t);
  }, []);

  // اصلاح باگ قدیمی: اگر قبلاً آموزش اولیه دیده شده بود ولی کاربر وارد نبود، دوباره اسلایدها را نشان می‌داد
  // و کاربر لاگین‌شده هم گاهی روی اسپلش می‌ماند. حالا بعد از اسپلش مسیر درست انتخاب می‌شود.
  useEffect(() => {
    if (!minDone || loading) return;
    if (user) {
      router.replace("/home");
      return;
    }
    let seen = false;
    try {
      seen = localStorage.getItem("forja_onboard") === "1";
    } catch {
      seen = false;
    }
    if (seen) router.replace("/login");
    else setPhase("onboard");
  }, [minDone, loading, user, router]);

  if (phase === "splash") {
    return (
      <div className="relative min-h-full" style={{ minHeight: "100%" }}>
        <img src={IMG.splash} alt="" className="hero-img absolute inset-0 h-full w-full" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/50 to-black" />
        <div className="relative z-10 flex min-h-[100dvh] flex-col items-center justify-end px-8 pb-24 text-center">
          <img src={IMG.logo} alt="فُرجا" className="mb-5 h-20 w-20 rounded-3xl pop" />
          <h1 className="text-5xl font-extrabold tracking-tight fade-up">فُرجا</h1>
          <p className="mt-2 text-sm text-[var(--muted)] fade-up-d1">مربی بدنسازی هوشمند</p>
          <p className="mt-1 text-[10px] text-white/30">نسخه {__BUILD__}</p>
          <div className="mt-8 h-1.5 w-28 overflow-hidden rounded-full bg-white/10">
            <div className="h-full w-full origin-right animate-[barGrow_3.4s_ease]" style={{ background: "linear-gradient(90deg,#c8f542,#ff5a1f)" }} />
          </div>
        </div>
      </div>
    );
  }

  const s = slides[i];
  return (
    <div className="relative flex min-h-full flex-col" style={{ minHeight: "100%" }}>
      <img src={s.img} alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/40 to-[#07070a]" />
      <div className="relative z-10 mt-auto px-6 pb-8">
        <div className="mb-5 flex gap-1">
          {slides.map((_, idx) => (
            <span key={idx} className="h-1 flex-1 rounded-full" style={{ background: idx <= i ? "#c8f542" : "rgba(255,255,255,0.2)" }} />
          ))}
        </div>
        <p className="chip mb-3">FORJA COACH</p>
        <h2 className="fade-up text-3xl font-extrabold leading-snug">{s.title}</h2>
        <p className="fade-up-d1 mt-3 text-[15px] leading-7 text-[var(--muted)]">{s.text}</p>
        <div className="mt-6 grid grid-cols-2 gap-3">
          {i < slides.length - 1 ? (
            <>
              <RippleButton
                className="btn-ghost"
                onClick={() => {
                  markOnboarded();
                  router.push(user ? "/home" : "/login");
                }}
              >
                رد کردن
              </RippleButton>
              <RippleButton className="btn-lime" onClick={() => setI(i + 1)}>
                بعدی
              </RippleButton>
            </>
          ) : (
            <>
              <RippleButton
                className="btn-ghost"
                onClick={() => {
                  markOnboarded();
                  router.push("/login");
                }}
              >
                ورود
              </RippleButton>
              <RippleButton
                className="btn-lime"
                onClick={() => {
                  markOnboarded();
                  router.push("/register");
                }}
              >
                شروع کن
              </RippleButton>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
