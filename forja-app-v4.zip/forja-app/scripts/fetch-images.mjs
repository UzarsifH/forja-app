// دانلود عکس واقعی برای هر اسلات (نیاز به اینترنت؛ در GitHub Actions خودکار اجرا می‌شود)
// ۱) Wikimedia Commons (جستجو با اسم حرکت)  ۲) loremflickr (برچسب)  ۳) اگر هیچ‌کدام نشد، عکس طراحی‌شده می‌ماند.
import fs from "node:fs";
import { PHOTOS } from "./photo-manifest.mjs";
const DIR = "public/images/photos";
const UA = { "User-Agent": "ForjaApp/1.0 (fitness app build; contact: app owner) node-fetch" };
fs.mkdirSync(DIR, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const get = async (url, tries = 3) => {
  for (let t = 0; t < tries; t++) {
    try {
      const r = await fetch(url, { headers: UA, redirect: "follow", signal: AbortSignal.timeout(30000) });
      if (r.ok) return r;
      if (r.status === 429) await sleep(3000 * (t + 1));
    } catch { await sleep(1500); }
  }
  return null;
};
const strip = (h = "") => h.replace(/<[^>]*>/g, "").trim();

async function commons(q) {
  const api = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=12" +
    `&gsrsearch=${encodeURIComponent(`filetype:bitmap ${q}`)}&prop=imageinfo&iiprop=url|mime|size|extmetadata&iiurlwidth=720`;
  const r = await get(api); if (!r) return null;
  const pages = Object.values((await r.json())?.query?.pages ?? {}).sort((a, b) => a.index - b.index);
  for (const p of pages) {
    const i = p.imageinfo?.[0];
    if (!i || i.mime !== "image/jpeg" || i.width < 600 || i.height < 500 || !i.thumburl) continue;
    const img = await get(i.thumburl); if (!img) continue;
    const buf = Buffer.from(await img.arrayBuffer());
    if (buf.length < 15000) continue;
    const m = i.extmetadata || {};
    return { buf, credit: { title: p.title, author: strip(m.Artist?.value), license: strip(m.LicenseShortName?.value), page: i.descriptionurl } };
  }
  return null;
}
async function flickr(tags, n) {
  const r = await get(`https://loremflickr.com/720/960/${tags}?lock=${n}`); if (!r) return null;
  const buf = Buffer.from(await r.arrayBuffer());
  return (r.headers.get("content-type") || "").startsWith("image/") && buf.length > 8000 ? { buf, credit: { title: "flickr:" + tags } } : null;
}

const rows = [], credits = {};
let n = 0;
for (const [slot, spec] of Object.entries(PHOTOS)) {
  n++;
  const { q, t } = typeof spec === "string" ? { q: spec, t: spec } : spec;
  let src = "commons", res = await commons(q);
  if (!res) { src = "flickr"; res = await flickr(t, n); }
  if (res) { fs.writeFileSync(`${DIR}/${slot}.jpg`, res.buf); credits[slot] = res.credit; } else src = "art";
  rows.push({ slot, src });
  console.log(src === "art" ? "✖ art   " : `✔ ${src}`, slot);
  await sleep(250);
}
fs.writeFileSync(`${DIR}/_credits.json`, JSON.stringify(credits, null, 1));
fs.writeFileSync(`${DIR}/_report.html`, `<meta charset=utf-8><body style="background:#111;color:#eee;font:12px sans-serif;display:grid;grid-template-columns:repeat(auto-fill,150px);gap:8px">` +
  rows.map((r) => `<div><img src="${r.slot}.jpg" width=150 height=200 style="object-fit:cover"><br>${r.slot} · ${r.src}</div>`).join(""));
const c = (s) => rows.filter((r) => r.src === s).length;
const sum = `photos: commons=${c("commons")} flickr=${c("flickr")} art(fallback)=${c("art")} of ${rows.length}`;
console.log("\n" + sum);
if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, `### ${sum}\n`);
