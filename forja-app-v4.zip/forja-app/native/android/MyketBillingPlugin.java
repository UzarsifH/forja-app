package __APP_ID__;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import com.android.vending.billing.IInAppBillingService;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.ArrayList;

/** Myket in-app billing (Google IAB v3 protocol) */
@CapacitorPlugin(name = "MyketBilling", requestCodes = {7311})
public class MyketBillingPlugin extends Plugin {
    private static final String MARKET = "ir.mservices.market";
    private static final String BIND = "ir.mservices.market.InAppBillingService.BIND";
    private static final int REQ = 7311;
    private IInAppBillingService svc;
    private ServiceConnection conn;
    private PluginCall pending;

    private interface Job { void run(IInAppBillingService s) throws Exception; }

    private void withService(final PluginCall call, final Job job) {
        if (svc != null) { runJob(call, job); return; }
        conn = new ServiceConnection() {
            @Override public void onServiceConnected(ComponentName n, IBinder b) { svc = IInAppBillingService.Stub.asInterface(b); runJob(call, job); }
            @Override public void onServiceDisconnected(ComponentName n) { svc = null; }
        };
        Intent i = new Intent(BIND);
        i.setPackage(MARKET);
        boolean ok = false;
        try { ok = getContext().bindService(i, conn, Context.BIND_AUTO_CREATE); } catch (Exception e) { ok = false; }
        if (!ok) call.reject("مایکت روی این گوشی نصب نیست یا سرویس پرداختش در دسترس نیست.", "NO_MYKET");
    }

    private void runJob(final PluginCall call, final Job job) {
        new Thread(() -> {
            try { job.run(svc); } catch (Exception e) { call.reject("خطا در ارتباط با مایکت: " + e.getMessage(), "ERR"); }
        }).start();
    }

    @PluginMethod
    public void purchase(final PluginCall call) {
        final String sku = call.getString("sku");
        final String payload = call.getString("payload", "");
        call.setKeepAlive(true);
        bridge.saveCall(call);
        withService(call, s -> {
            Bundle b = s.getBuyIntent(3, getContext().getPackageName(), sku, "inapp", payload);
            int rc = b.getInt("RESPONSE_CODE", 6);
            if (rc != 0 && rc != 7) { Bundle b2 = s.getBuyIntent(3, getContext().getPackageName(), sku, "subs", payload); if (b2.getInt("RESPONSE_CODE", 6) == 0) { b = b2; rc = 0; } }
            if (rc != 0) { call.reject("پاسخ مایکت: " + rc, String.valueOf(rc)); return; }
            final PendingIntent pi = b.getParcelable("BUY_INTENT");
            pending = call;
            getActivity().runOnUiThread(() -> {
                try {
                    getActivity().startIntentSenderForResult(pi.getIntentSender(), REQ, new Intent(), 0, 0, 0);
                } catch (Exception e) { call.reject("باز کردن صفحه پرداخت ممکن نشد", "ERR"); }
            });
        });
    }

    @Override
    protected void handleOnActivityResult(int requestCode, int resultCode, Intent data) {
        super.handleOnActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ || pending == null) return;
        PluginCall call = pending; pending = null;
        bridge.releaseCall(call);
        int rc = data != null ? data.getIntExtra("RESPONSE_CODE", 6) : 1;
        if (resultCode == android.app.Activity.RESULT_OK && rc == 0 && data != null) {
            JSObject o = new JSObject();
            o.put("purchaseData", data.getStringExtra("INAPP_PURCHASE_DATA"));
            o.put("signature", data.getStringExtra("INAPP_DATA_SIGNATURE"));
            call.resolve(o);
        } else {
            call.reject(rc == 1 ? "پرداخت لغو شد" : "پرداخت انجام نشد (" + rc + ")", String.valueOf(rc));
        }
    }

    /** خریدهای مصرف‌نشده (مثلاً اگر پرداخت انجام شده ولی اشتراک ثبت نشده) */
    @PluginMethod
    public void owned(final PluginCall call) {
        withService(call, s -> {
            Bundle b = s.getPurchases(3, getContext().getPackageName(), "inapp", null);
            if (b.getInt("RESPONSE_CODE", 6) != 0) { call.reject("خطا در دریافت خریدها", "ERR"); return; }
            ArrayList<String> d = b.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
            ArrayList<String> sg = b.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
            JSArray arr = new JSArray();
            if (d != null) for (int i = 0; i < d.size(); i++) {
                JSObject o = new JSObject(); o.put("purchaseData", d.get(i)); o.put("signature", sg != null ? sg.get(i) : ""); arr.put(o);
            }
            JSObject r = new JSObject(); r.put("items", arr); call.resolve(r);
        });
    }

    @PluginMethod
    public void consume(final PluginCall call) {
        final String token = call.getString("purchaseToken");
        withService(call, s -> {
            int rc = s.consumePurchase(3, getContext().getPackageName(), token);
            JSObject r = new JSObject(); r.put("code", rc); call.resolve(r);
        });
    }
}
