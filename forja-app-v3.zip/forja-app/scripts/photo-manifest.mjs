// هر اسلات عکس = یک ردیف. برچسب‌ها (tags) برای جستجوی عکس واقعی است؛ برای عوض‌کردن یک عکس، tags را تغییر بده
// یا مستقیم url بگذار (آدرس مستقیم عکس). فایل نهایی: public/images/photos/<slot>.jpg
export const PHOTOS = {
  // حرکات
  "ex-bench": "bench,barbell,gym", "ex-incline_db": "dumbbell,bench,chest", "ex-pushup": "pushup,fitness", "ex-chest_fly": "dumbbell,chest,gym",
  "ex-dips": "dips,calisthenics", "ex-band_press": "resistance,band,workout", "ex-pulldown": "latpulldown,gym", "ex-bb_row": "barbell,row,deadlift",
  "ex-seated_row": "rowing,gym,machine", "ex-pullup": "pullup,calisthenics", "ex-superman": "back,exercise,fitness", "ex-band_row": "resistance,band,fitness",
  "ex-ohp": "overhead,press,barbell", "ex-db_press": "dumbbell,shoulder,press", "ex-lateral": "dumbbell,shoulder,gym", "ex-rear_fly": "dumbbell,workout,back",
  "ex-face": "cable,gym,shoulder", "ex-pike_push": "pushup,handstand,calisthenics", "ex-curl": "biceps,curl,barbell", "ex-hammer": "biceps,dumbbell,curl",
  "ex-band_curl": "resistance,band,biceps", "ex-pushdown": "triceps,cable,gym", "ex-skull": "triceps,dumbbell,bench", "ex-bench_dip": "dips,bench,triceps",
  "ex-oh_ext": "triceps,dumbbell,workout", "ex-squat": "squat,barbell,powerlifting", "ex-goblet": "squat,dumbbell,kettlebell", "ex-lunge": "lunge,fitness,legs",
  "ex-leg_press": "legpress,gym,machine", "ex-split_squat": "lunge,dumbbell,legs", "ex-bw_squat": "squat,bodyweight,fitness", "ex-rdl": "deadlift,barbell,gym",
  "ex-hip_hinge": "deadlift,kettlebell,gym", "ex-leg_curl": "legcurl,gym,machine", "ex-thrust": "hipthrust,glutes,gym", "ex-bridge": "glute,bridge,yoga",
  "ex-kickback": "glutes,workout,fitness", "ex-calf": "calf,raise,gym", "ex-seated_calf": "calves,gym,machine", "ex-plank": "plank,core,fitness",
  "ex-deadbug": "core,exercise,mat", "ex-hanging_knee": "hanging,legraise,abs", "ex-bicycle": "abs,crunch,workout", "ex-bird_dog": "yoga,mat,core",
  "ex-walk": "treadmill,incline,walking", "ex-bike": "spinning,bike,gym", "ex-jump_rope": "jumprope,boxing,fitness", "ex-mountain": "mountainclimber,fitness,workout",
  "ex-burpee": "burpee,crossfit,workout", "ex-farmer": "kettlebell,carry,strongman",
  // عضلات
  "m-chest": "chest,bodybuilder,muscle", "m-back": "back,bodybuilder,muscle", "m-shoulders": "shoulders,bodybuilder,muscle", "m-biceps": "biceps,flex,muscle",
  "m-triceps": "triceps,arm,muscle", "m-quads": "quads,legs,squat", "m-hamstrings": "hamstrings,legs,deadlift", "m-glutes": "glutes,woman,gym",
  "m-calves": "calves,legs,running", "m-core": "abs,sixpack,fitness", "m-full": "athlete,fitness,training",
  // صفحه‌های اپ
  "a-hero": "bodybuilder,gym,training", "a-premium": "athlete,gym,muscle", "a-coach": "personaltrainer,gym,coach", "a-results": "fitness,transformation,athlete",
  "a-athleteRed": "athlete,sprint,training", "a-poseGym": "bodybuilder,pose,gym", "a-dumbbell": "dumbbells,gym,weights", "a-beanie": "athlete,beanie,gym",
  "a-bwPose": "athlete,blackandwhite,muscle", "a-womanTrain": "woman,gym,workout", "a-womanSquat": "woman,squat,gym", "a-womanCurl": "woman,dumbbell,gym",
  "a-restGym": "gym,rest,athlete", "a-glasses": "athlete,sunglasses,gym", "a-chest": "chest,bodybuilder,gym", "a-biceps": "biceps,flex,gym",
  "a-backMuscle": "back,muscle,bodybuilder", "a-squat": "squat,barbell,gym", "a-incline": "bench,incline,dumbbell", "a-bench": "bench,press,gym",
  "a-press": "overhead,press,gym", "a-pullupW": "woman,pullup,gym", "a-pullupM": "pullup,man,gym", "a-back": "barbell,row,back", "a-triceps": "triceps,cable,gym",
};
