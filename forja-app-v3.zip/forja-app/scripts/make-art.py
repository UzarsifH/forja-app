# Generates all FORJA artwork locally (no internet): python3 scripts/make-art.py
import numpy as np, math, os
from PIL import Image, ImageDraw, ImageFilter
S=2; W,H=720,960; OUT="public/images"; os.makedirs(OUT,exist_ok=True)
mix=lambda a,b,t:tuple(int(a[i]*(1-t)+b[i]*t) for i in range(3))
SKIN=[(224,172,132),(176,122,86),(240,195,160),(142,94,66)]
def bg(c1,c2,acc,cx=.5,cy=.4,floor=None):
    y=np.linspace(0,1,H*S)[:,None,None]; a=np.array(c1)[None,None,:]; b=np.array(c2)[None,None,:]
    g=a*(1-y)+b*y; g=np.repeat(g,W*S,1)
    yy,xx=np.mgrid[0:H*S,0:W*S]; d=np.hypot(xx/(W*S)-cx,(yy/(H*S)-cy)*1.3)
    g=g+np.array(acc)[None,None,:]*np.clip(.55-d,0,1)[...,None]*.9
    im=Image.fromarray(np.clip(g,0,255).astype('uint8')).convert('RGBA'); d=ImageDraw.Draw(im)
    for i in range(0,W,60): d.line([(i*S,0),(i*S,H*S)],fill=acc+(14,),width=2)
    for j in range(0,H,60): d.line([(0,j*S),(W*S,j*S)],fill=acc+(14,),width=2)
    if floor: d.rectangle([0,floor*S,W*S,H*S],fill=(0,0,0,110)); d.line([(0,floor*S),(W*S,floor*S)],fill=acc+(200,),width=5)
    return im
class P:
    def __init__(s,im,acc): s.im=im; s.d=ImageDraw.Draw(im); s.acc=acc
    def c(s,a,r,f): s.d.ellipse([(a[0]-r)*S,(a[1]-r)*S,(a[0]+r)*S,(a[1]+r)*S],fill=f)
    def cap(s,a,b,ra,rb,f):
        dx,dy=b[0]-a[0],b[1]-a[1]; L=math.hypot(dx,dy) or 1; nx,ny=-dy/L,dx/L
        s.d.polygon([((a[0]+nx*ra)*S,(a[1]+ny*ra)*S),((b[0]+nx*rb)*S,(b[1]+ny*rb)*S),((b[0]-nx*rb)*S,(b[1]-ny*rb)*S),((a[0]-nx*ra)*S,(a[1]-ny*ra)*S)],fill=f); s.c(a,ra,f); s.c(b,rb,f)
    def limb(s,a,b,ra,rb,f):
        s.cap(a,b,ra,rb,mix(f,(0,0,0),.25)); o=(-ra*.3,-ra*.3)
        s.cap((a[0]+o[0],a[1]+o[1]),(b[0]+o[0],b[1]+o[1]),ra*.5,rb*.5,mix(f,(255,255,255),.22))
    def line(s,a,b,w,f): s.d.line([a[0]*S,a[1]*S,b[0]*S,b[1]*S],fill=f,width=int(w*S))
    def plate(s,a,r): s.c(a,r,(25,25,30)); s.c(a,r*.86,mix(s.acc,(0,0,0),.55)); s.c(a,r*.6,(35,35,42)); s.c(a,r*.2,(200,200,205))
    def db(s,a,ang=0,sz=1):
        dx,dy=math.cos(ang)*34*sz,math.sin(ang)*34*sz; s.line((a[0]-dx,a[1]-dy),(a[0]+dx,a[1]+dy),9*sz,(190,190,195)); 
        for k in(-1,1): s.cap((a[0]+k*dx,a[1]+k*dy),(a[0]+k*dx*.55,a[1]+k*dy*.55),17*sz,17*sz,(30,30,36))
    def rect(s,x0,y0,x1,y1,f): s.d.rounded_rectangle([x0*S,y0*S,x1*S,y1*S],radius=14*S,fill=f)
def figure(p,sh,hip,head,arms,legs,skin,shirt,shorts,rs=52,rh=48,hr=38,pre=None,post=None):
    if pre: pre(p)
    arms=[(sh,a[0],a[1],a[3]) if a[2]==0 else a for a in arms]
    lim=lambda a,b,ra,rb:p.limb(a,b,ra,rb,skin); dim=lambda c:mix(c,(0,0,0),.35)
    def leg(l,near):
        h,k,f=l; sk=skin if near else dim(skin); p.limb(h,k,rh*.82,rh*.6,sk); p.limb(k,f,rh*.58,rh*.4,sk)
        p.cap(h,(h[0]+(k[0]-h[0])*.55,h[1]+(k[1]-h[1])*.55),rh*.9,rh*.75,shorts if near else dim(shorts))
        dx=1 if f[0]>=k[0] else -1; p.cap(f,(f[0]+dx*34,f[1]+4),13,9,(235,235,240) if near else (120,120,125))
    def arm(a,near):
        s0,e,h=a; sk=skin if near else dim(skin); p.limb(s0,e,rs*.42,rs*.34,sk); p.limb(e,h,rs*.34,rs*.26,sk); p.c(h,rs*.27,sk)
    for l in legs:
        if not l[3]: leg(l[:3],0)
    for a in arms:
        if not a[3]: arm(a[:3],0)
    p.cap(sh,hip,rs,rh,mix(shirt,(0,0,0),.3)); o=(-rs*.35,0); p.cap((sh[0]+o[0],sh[1]),(hip[0]+o[0]*.5,hip[1]),rs*.5,rh*.45,shirt)
    nk=(sh[0]+(head[0]-sh[0])*.5,sh[1]+(head[1]-sh[1])*.5); p.cap(sh,head,rs*.3,rs*.28,mix(skin,(0,0,0),.2)); p.c(head,hr,mix(skin,(0,0,0),.18)); p.c((head[0]-6,head[1]-6),hr*.8,skin)
    p.d.pieslice([(head[0]-hr)*S,(head[1]-hr)*S,(head[0]+hr)*S,(head[1]+hr)*S],180,330,fill=(22,18,18))
    for l in legs:
        if l[3]: leg(l[:3],1)
    for a in arms:
        if a[3]: arm(a[:3],1)
    if post: post(p)
def save(im,name,gray=False,png=False):
    im=im.resize((W,H),Image.LANCZOS).convert('RGB')
    if gray: im=im.convert('L').convert('RGB')
    im.save(f"{OUT}/{name}.jpg",quality=88)
def bar(p,a,b): p.line(a,b,8,(200,200,205))
A=lambda x,y:(x,y)
def scene(name,c1,c2,acc,fl,fn,skin=0,shirt=None,shorts=None,gray=False,glow=(.5,.45)):
    im=bg(c1,c2,acc,*glow,floor=fl); lay=Image.new('RGBA',im.size,(0,0,0,0)); p=P(lay,acc); fn(p,SKIN[skin],shirt or mix(acc,(0,0,0),.35),shorts or (24,24,30))
    al=lay.split()[3].filter(ImageFilter.GaussianBlur(40*S)); gl=Image.new('RGBA',im.size,acc+(0,)); gl.putalpha(al.point(lambda v:int(v*.75))); im=Image.alpha_composite(im,gl); sh=Image.new('RGBA',im.size,(0,0,0,0))
    im=Image.alpha_composite(im,lay); save(im,name,gray)
R,O,C,V,G,B,PK=(255,60,60),(255,140,30),(40,200,255),(150,90,255),(255,200,40),(60,140,255),(255,70,160)
D1,D2=(10,10,16),(24,12,20)
# --- exercise scenes (side view) ---
def squat(p,sk,sf,sh_):
    pre=lambda p:(p.plate((372,436),92))
    figure(p,(380,440),(290,650),(405,368),[((330,520),(400,440),0,1),((340,530),(410,445),0,0)],[((290,650),(470,640),(410,800),1),((300,655),(485,650),(440,800),0)],sk,sf,sh_,post=lambda p:p.plate((372,436),92) and None)
def goblet(p,sk,sf,sh_):
    figure(p,(360,440),(305,630),(375,372),[((400,540),(450,480),0,1),((395,545),(445,490),0,0)],[((305,630),(465,640),(420,800),1),((315,635),(480,650),(450,800),0)],sk,sf,sh_,post=lambda p:p.db((455,484),math.pi/2,1.2))
def bench(p,sk,sf,sh_):
    pre=lambda p:(p.rect(130,615,620,665,(40,40,50)),p.rect(220,665,250,800,(40,40,50)),p.rect(500,665,530,800,(40,40,50)))
    figure(p,(260,575),(450,580),(185,570),[((262,460),(265,345),0,1),((275,465),(278,350),0,0)],[((450,580),(550,470),(565,790),1),((440,585),(530,480),(540,790),0)],sk,sf,sh_,pre=pre,post=lambda p:(p.line((150,345),(380,345),9,(200,200,205)),p.plate((165,345),80),p.plate((365,345),80)))
def incline(p,sk,sf,sh_):
    pre=lambda p:(p.line((200,720),(430,560),70,(40,40,50)),p.line((430,560),(560,600),60,(40,40,50)),p.rect(250,720,280,800,(40,40,50)))
    figure(p,(300,560),(430,630),(255,505),[((355,450),(340,330),0,1),((350,455),(330,335),0,0)],[((430,630),(545,560),(560,790),1),((440,640),(560,570),(580,790),0)],sk,sf,sh_,pre=pre,post=lambda p:(p.db((340,330),0,1.4),p.db((330,335),0,1.4)))
def pushup(p,sk,sf,sh_):
    figure(p,(250,520),(470,585),(185,500),[((245,615),(250,725),0,1),((260,620),(265,725),0,0)],[((470,585),(580,630),(690,700),1),((480,590),(590,635),(705,705),0)],sk,sf,sh_,rs=52,rh=44)
def pullup(p,sk,sf,sh_,lo=0):
    pre=lambda p:(p.line((180,215),(540,215),12,(210,210,215)),p.rect(160,200,185,330,(40,40,50)),p.rect(535,200,560,330,(40,40,50)))
    y=lo
    figure(p,(375,300+y),(375,540+y),(385,235+y),[((330,300+y),(365,215),0,1),((345,300+y),(385,215),0,0)],[((375,540+y),(410,660+y),(350,760+y),1),((380,545+y),(430,665+y),(375,765+y),0)],sk,sf,sh_,pre=pre)
def row(p,sk,sf,sh_):
    figure(p,(500,470),(300,570),(560,450),[((470,545),(485,610),0,1),((480,550),(500,620),0,0)],[((300,570),(345,690),(330,800),1),((310,575),(360,695),(355,800),0)],sk,sf,sh_,post=lambda p:(p.line((300,640),(660,640),9,(200,200,205)),p.plate((600,640),70)))
def ohp(p,sk,sf,sh_):
    figure(p,(360,430),(350,615),(365,358),[((410,340),(395,225),0,1),((400,345),(380,230),0,0)],[((350,615),(365,710),(355,800),1),((340,620),(335,715),(325,800),0)],sk,sf,sh_,post=lambda p:(p.db((395,222),0,1.5),p.db((380,228),0,1.5)))
def curl(p,sk,sf,sh_):
    figure(p,(360,430),(350,615),(368,358),[((385,525),(455,455),0,1),((375,530),(440,470),0,0)],[((350,615),(365,710),(355,800),1),((340,620),(335,715),(325,800),0)],sk,sf,sh_,post=lambda p:p.db((457,452),math.pi/2,1.3))
def tri(p,sk,sf,sh_):
    pre=lambda p:(p.line((560,60),(560,330),14,(60,60,70)),p.line((560,90),(445,560),5,(210,210,215)),p.rect(520,40,600,90,(50,50,60)))
    figure(p,(360,430),(350,615),(368,358),[((385,530),(445,575),0,1),((375,535),(440,585),0,0)],[((350,615),(365,710),(355,800),1),((340,620),(335,715),(325,800),0)],sk,sf,sh_,pre=pre)
def front(arms,rs=95,rh=64,hr=44,legs=True,sh=(360,390),hp=(360,640)):
    def fn(p,sk,sf,sh_):
        L=[((330,650),(320,760),(318,850),1),((390,650),(400,760),(402,850),1)]
        figure(p,sh,hp,(360,sh[1]-85),arms,L,sk,sf,sh_,rs=rs,rh=rh,hr=hr)
    return fn
bic=front([((285,395),(150,400),(150,255),1),((435,395),(570,400),(570,255),1)])
chest=front([((290,395),(235,500),(335,555),1),((430,395),(485,500),(385,555),1)],rs=105)
pose=front([((285,395),(160,360),(100,260),1),((435,395),(560,360),(620,260),1)])
back=front([((270,395),(185,480),(235,590),1),((450,395),(535,480),(485,590),1)],rs=115,rh=60)
def vsit(p,sk,sf,sh_):
    figure(p,(280,480),(370,650),(250,415),[((350,520),(445,570),0,1),((345,525),(440,580),0,0)],[((370,650),(480,540),(590,420),1),((380,655),(490,550),(600,430),0)],sk,sf,sh_)
def rest(p,sk,sf,sh_):
    pre=lambda p:p.rect(190,655,520,700,(40,40,50))
    figure(p,(335,455),(335,650),(340,385),[((420,560),(470,615),0,1),((430,565),(480,620),0,0)],[((335,650),(490,625),(505,800),1),((345,655),(510,635),(535,800),0)],sk,sf,sh_,pre=pre,post=lambda p:p.cap((470,612),(555,560),20,20,(240,240,240)))
def sprint(p,sk,sf,sh_):
    figure(p,(380,440),(335,620),(430,375),[((445,520),(390,610),0,1),((330,520),(285,430),0,0)],[((335,620),(430,700),(330,780),0),((335,620),(470,640),(570,730),1)],sk,sf,sh_)
# --- busts ---
def bust(p,sk,sf,sh_,kind):
    p.cap((360,700),(360,860),230,260,mix(sf,(0,0,0),.3)); p.cap((300,720),(300,860),150,170,sf); p.cap((360,560),(360,640),42,52,sk)
    p.c((360,430),112,mix(sk,(0,0,0),.2)); p.c((350,425),108,sk)
    p.c((248,440),20,sk); p.c((472,440),20,mix(sk,(0,0,0),.2))
    for x in(318,402): p.c((x,440),7,(30,22,20))
    p.line((325,505),(395,505),6,mix(sk,(0,0,0),.55))
    if kind=="glasses":
        for x in(305,415): p.rect(x-52,405,x+52,465,(18,18,22)); p.rect(x-44,411,x-10,430,(255,255,255,70))
        p.line((357,430),(363,430),9,(18,18,22)); p.line((253,430),(215,422),7,(18,18,22)); p.line((467,430),(505,422),7,(18,18,22))
    if kind=="beanie":
        p.d.pieslice([245*S,290*S,475*S,500*S],180,360,fill=p.acc+(255,)); p.rect(244,372,476,410,mix(p.acc,(0,0,0),.4)); p.c((360,288),22,(240,240,240))
    if kind=="coach":
        p.rect(248,330,472,372,(25,25,30)); p.cap((360,640),(420,730),5,5,(220,220,225)); p.c((420,742),22,(235,200,40)); p.c((420,742),9,(40,40,40))
        p.rect(520,640,650,820,(235,235,240)); 
        for j in range(4): p.line((540,675+j*32),(630,675+j*32),6,p.acc)
def mk(name,c1,c2,acc,fn,**k): scene(name,c1,c2,acc,k.pop('fl',None),fn,**k)
def sc(name,c1,c2,acc,fl,fn,**k): mk(name,c1,c2,acc,fn,fl=fl,**k)
sc("squat",D1,(30,14,14),R,810,squat,skin=1)
sc("womanSquat",(14,10,24),(36,12,40),PK,810,goblet,skin=2)
sc("bench",D1,(10,20,34),B,810,bench,skin=0)
sc("incline",D1,(28,20,10),O,810,incline,skin=3)
sc("press",(8,14,18),(10,34,40),C,730,pushup,skin=1)
sc("pullupW",(14,10,24),(30,14,44),V,None,lambda p,a,b,c:pullup(p,a,b,c,30),skin=2)
sc("pullupM",D1,(14,20,40),B,None,pullup,skin=0)
sc("back",D1,(34,12,12),R,810,row,skin=3)
sc("dumbbell",D1,(34,26,8),G,810,ohp,skin=1)
sc("womanTrain",(8,14,20),(8,36,44),C,810,curl,skin=2)
sc("womanCurl",(14,10,24),(40,10,34),PK,810,curl,skin=2)
sc("triceps",(8,14,20),(8,34,40),C,810,tri,skin=3)
sc("biceps",D1,(40,16,8),O,None,bic,skin=1,glow=(.5,.35))
sc("chest",D1,(10,18,40),B,None,chest,skin=0,glow=(.5,.35))
sc("back-muscle",D1,(36,10,28),PK,None,back,skin=3,glow=(.5,.35))
sc("poseGym",D1,(20,14,44),V,None,pose,skin=1,glow=(.5,.35))
sc("athleteRed",(20,6,8),(60,10,14),R,810,sprint,skin=0)
sc("bwPose",(10,10,10),(40,40,40),(210,210,210),810,vsit,skin=0,gray=True)
sc("restGym",(8,18,20),(10,40,40),C,810,rest,skin=2)
for nm,k,ac,c2,sk in(("glasses","glasses",O,(40,20,8),1),("beanie","beanie",C,(8,34,40),0),("coach","coach",G,(36,28,8),3)):
    sc(nm,D1,c2,ac,None,lambda p,a,b,c,k=k:bust(p,a,b,c,k),skin=sk,glow=(.5,.5))
# --- logo / composition scenes ---
def Fmark(sz,c1=(255,170,40),c2=(255,50,60),white=False):
    m=Image.new('L',(sz*2,sz*2),0); d=ImageDraw.Draw(m); k=sz*2/100
    for poly in([(24,14),(80,14),(72,32),(46,32),(46,44),(68,44),(61,60),(46,60),(46,86),(24,86)],):
        d.polygon([(x*k,y*k) for x,y in poly],fill=255)
    m=m.filter(ImageFilter.GaussianBlur(.6)).resize((sz,sz),Image.LANCZOS)
    g=np.zeros((sz,sz,3),'float'); t=np.linspace(0,1,sz)[:,None]
    for i in range(3): g[...,i]=(c1[i]*(1-t)+c2[i]*t)
    im=Image.fromarray(g.astype('uint8') if not white else np.full((sz,sz,3),255,'uint8')).convert('RGBA'); im.putalpha(m); return im
def logo_scene(name,acc,c2):
    im=bg(D1,c2,acc,.5,.45); lg=Fmark(560*S).resize((560*S,560*S)); im.alpha_composite(lg,((W*S-560*S)//2,150*S)); 
    d=ImageDraw.Draw(im); d.rounded_rectangle([230*S,760*S,490*S,772*S],radius=6*S,fill=acc+(255,)); save(im,name)
logo_scene("splash",O,(40,12,10)); logo_scene("hero",R,(44,10,14))
def premium():
    im=bg((12,10,6),(48,34,6),G,.5,.4); p=P(im,G)
    for i,(x,y) in enumerate([(120,200),(600,260),(540,720),(160,700),(360,140)]):
        for a in (0,45): p.d.polygon([((x+math.cos(math.radians(a+q))*r)*S,(y+math.sin(math.radians(a+q))*r)*S) for q,r in((0,36),(45,6),(90,36),(135,6),(180,36),(225,6),(270,36),(315,6))],fill=(255,225,120,200))
    pts=[(170,560),(170,380),(265,470),(360,330),(455,470),(550,380),(550,560)]
    p.d.polygon([(x*S,y*S) for x,y in pts],fill=(120,80,10)); p.d.polygon([((x-6)*S,(y-6)*S) for x,y in pts],fill=(255,205,60))
    p.d.rounded_rectangle([160*S,570*S,560*S,640*S],radius=18*S,fill=(255,225,110))
    for x,c in((230,R),(360,B),(490,C)): p.c((x,605),20,c)
    for x,y in((170,380),(360,330),(550,380)): p.c((x,y-6),18,(255,240,170))
    save(im,"premium")
premium()
def results():
    im=bg(D1,(8,34,24),(40,230,140),.5,.5,floor=800); p=P(im,(40,230,140))
    for i,h in enumerate((130,210,300,410,540)):
        x=110+i*115; p.d.rounded_rectangle([x*S,(800-h)*S,(x+80)*S,800*S],radius=12*S,fill=mix((40,230,140),(0,0,0),.55-.1*i)); p.d.rounded_rectangle([(x+6)*S,(806-h)*S,(x+30)*S,794*S],radius=8*S,fill=mix((40,230,140),(255,255,255),.15))
    p.line((120,420),(380,300),14,(255,255,255,230)); p.line((380,300),(560,150),14,(255,255,255,230)); p.d.polygon([(600*S,110*S),(520*S,150*S),(575*S,205*S)],fill=(255,255,255,240))
    save(im,"results")
results()
def motivation():
    im=bg((20,8,30),(70,20,20),O,.5,.62); p=P(im,O)
    for a in range(200,341,10): p.line((360,620),(360+900*math.cos(math.radians(a)),620+900*math.sin(math.radians(a))),14,(255,170,60,38))
    p.c((360,620),120,(255,200,90)); p.c((360,620),90,(255,240,170))
    p.d.polygon([(x*S,y*S) for x,y in[(0,960),(0,640),(130,560),(250,680),(380,500),(520,660),(620,590),(720,680),(720,960)]],fill=(18,10,20))
    p.d.polygon([(x*S,y*S) for x,y in[(380,500),(520,660),(250,680)]],fill=(34,18,30))
    figure(p,(380,425),(380,470),(383,395),[((350,440),(300,390),0,1)]*0+[((395,430),(350,375),(325,330),1)],[((380,470),(365,520),(355,560),1)],SKIN[1],(255,140,30),(16,16,20),rs=14,rh=12,hr=11)
    save(im,"motivation")
motivation()
def gym():
    im=bg(D1,(18,22,40),B,.5,.4,floor=700); p=P(im,B)
    for x in(80,640): p.rect(x-14,200,x+14,700,(45,45,55))
    for y,c in((330,(60,60,70)),(480,(60,60,70))): p.line((60,y),(660,y),10,c)
    for i,y in enumerate((520,520,520,520,520)):
        x=120+i*120; p.rect(x-18,y,x+18,y+130,(35,35,42)); p.d.rectangle([(x-18)*S,(y+40)*S,(x+18)*S,(y+130)*S],fill=(60,60,70))
    for i in range(6):
        x=100+i*100; h=60+i*6; p.db((x,690-h//2),0,1.15)
    for x in(150,300,450,570): p.plate((x,260),48-(x%3)*3)
    save(im,"gym")
gym()
def running():
    im=bg((8,10,24),(30,12,50),V,.55,.4); p=P(im,V)
    for i in range(7): p.line((360+(i-3)*20,420),(360+(i-3)*220,960),5,(255,255,255,90))
    for y in(520,600,720,880): p.line((0,y),(720,y),3,(255,255,255,50))
    lay=Image.new('RGBA',im.size,(0,0,0,0)); q=P(lay,V); figure(q,(380,440),(335,620),(430,375),[((445,520),(390,610),(0,0),1)][:0]+[((445,520),(390,610),(375,560),1),((330,520),(285,430),(240,490),0)],[((335,620),(430,700),(330,780),0),((335,620),(470,640),(570,730),1)],SKIN[0],V,(24,24,30))
    al=lay.split()[3].filter(ImageFilter.GaussianBlur(40*S)); gl=Image.new('RGBA',im.size,V+(0,)); gl.putalpha(al.point(lambda v:int(v*.8))); im=Image.alpha_composite(im,gl); im=Image.alpha_composite(im,lay); save(im,"running")
running()
def nutrition():
    im=bg((10,16,8),(20,40,14),(120,230,70),.5,.5); p=P(im,(120,230,70))
    p.c((360,520),290,(30,34,30)); p.c((360,520),262,(238,238,232)); p.c((360,520),200,(222,222,214))
    p.c((300,470),70,(76,175,60)); [p.c((300+dx,470+dy),r,(60,150,50)) for dx,dy,r in((-45,-30,36),(40,-35,34),(-10,-70,32),(55,15,30))]
    p.d.ellipse([380*S,520*S,540*S,640*S],fill=(255,245,225)); p.d.ellipse([430*S,555*S,480*S,605*S],fill=(255,190,40))
    p.d.ellipse([200*S,560*S,340*S,660*S],fill=(210,90,60)); p.d.ellipse([360*S,380*S,520*S,490*S],fill=(150,200,70)); p.c((440,435),32,(120,60,30))
    p.d.ellipse([140*S,120*S,300*S,300*S],fill=(220,40,40)); p.line((220,125),(240,80),8,(60,120,40))
    save(im,"nutrition")
nutrition()
# --- app icon / splash assets ---
os.makedirs("assets",exist_ok=True)
fg=Fmark(560); 
def icon(sz,full):
    base=bg(D1,(44,12,16),R,.5,.5).resize((sz,sz)) if full else Image.new('RGBA',(sz,sz),(0,0,0,0))
    return base
sz=1024
bgi=Image.fromarray(np.clip(np.array(bg(D1,(48,12,16),R,.5,.5).resize((sz,sz)))[...,:3],0,255).astype('uint8')).convert('RGBA'); bgi.convert('RGB').save("assets/icon-background.png")
f=Fmark(int(sz*.6)); only=bgi.copy(); only.alpha_composite(f,((sz-f.width)//2,(sz-f.height)//2)); only.convert('RGB').save("assets/icon-only.png")
t=Image.new('RGBA',(sz,sz),(0,0,0,0)); t.alpha_composite(f,((sz-f.width)//2,(sz-f.height)//2)); t.save("assets/icon-foreground.png")
Fmark(768).save(f"{OUT}/logo.png"); Fmark(768,white=True).save(f"{OUT}/logo-white.png")
sp=Image.fromarray(np.clip(np.array(bg(D1,(36,10,12),O,.5,.5).resize((2732,2732)))[...,:3],0,255).astype('uint8')).convert('RGBA'); g=Fmark(900); sp.alpha_composite(g,((2732-900)//2,(2732-900)//2)); sp.convert('RGB').save("assets/splash.png"); sp.convert('RGB').save("assets/splash-dark.png")
print("done")
