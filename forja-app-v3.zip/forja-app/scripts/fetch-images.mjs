// دانلود عکس‌های واقعی (نیاز به اینترنت؛ در GitHub Actions خودکار اجرا می‌شود): npm run images:fetch
// اگر دانلود یک عکس خطا بدهد، همان عکس طراحی‌شده‌ی قبلی می‌ماند و بیلد خراب نمی‌شود.
import fs from "node:fs";
import { PHOTOS } from "./photo-manifest.mjs";
const DIR = "public/images/photos";
fs.mkdirSync(DIR, { recursive: true });
const rows = [];
let n = 0;
for (const [slot, spec] of Object.entries(PHOTOS)) {
  n++;
  const url = spec.startsWith("http") ? spec : `https://loremflickr.com/720/960/${spec}?lock=${n}`;
  let ok = false;
  for (let t = 0; t < 3 && !ok; t++) {
    try {
      const r = await fetch(url, { redirect: "follow", signal: AbortSignal.timeout(30000) });
      const buf = Buffer.from(await r.arrayBuffer());
      if (r.ok && (r.headers.get("content-type") || "").startsWith("image/") && buf.length > 8000) {
        fs.writeFileSync(`${DIR}/${slot}.jpg`, buf);
        ok = true;
      }
    } catch { /* retry */ }
  }
  rows.push({ slot, spec, ok });
  console.log(ok ? "✔" : "✖ (عکس جایگزین می‌ماند)", slot);
}
const html = `<meta charset=utf-8><body style="background:#111;color:#eee;font:12px sans-serif;display:grid;grid-template-columns:repeat(auto-fill,150px);gap:8px">` +
  rows.map((r) => `<div><img src="${r.slot}.jpg" width=150 height=200 style="object-fit:cover"><br>${r.slot} ${r.ok ? "✔" : "✖"}</div>`).join("");
fs.writeFileSync(`${DIR}/_report.html`, html);
console.log(`\n${rows.filter((r) => r.ok).length}/${rows.length} عکس واقعی دانلود شد. گزارش: ${DIR}/_report.html`);
