import { apiFetch } from "@/lib/api";
import { useEffect, useMemo, useState } from "react";
import { muscleName } from "@/lib/exercises";
import { useAuth } from "@/components/Providers";
import { useRouter } from "@/lib/nav";

type Item = {
  id: string;
  nameFa: string;
  nameEn: string;
  muscle: string;
  level: string;
  image: string;
  equipment: string[];
  instructions: string[];
  tip: string;
};

const muscles = ["all", "chest", "back", "shoulders", "biceps", "triceps", "quads", "glutes", "core"];

export default function ExplorePage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [items, setItems] = useState<Item[]>([]);
  const [q, setQ] = useState("");
  const [m, setM] = useState("all");
  const [open, setOpen] = useState<Item | null>(null);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    void apiFetch("/api/exercises")
      .then((r) => r.json())
      .then((d) => setItems(d.exercises || []));
  }, []);

  const filtered = useMemo(
    () =>
      items.filter((e) => {
        if (m !== "all" && e.muscle !== m) return false;
        if (q && !e.nameFa.includes(q) && !e.nameEn.toLowerCase().includes(q.toLowerCase())) return false;
        return true;
      }),
    [items, q, m],
  );

  return (
    <div className="px-4 pb-6 pt-8">
      <h1 className="text-2xl font-extrabold">دانشنامه حرکات</h1>
      <p className="mt-1 text-xs text-[var(--muted)]">تصاویر واقعی تمرین، نه کلیپ‌آرت.</p>
      <input className="field mt-4" placeholder="جستجوی حرکت..." value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        {muscles.map((x) => (
          <button
            key={x}
            onClick={() => setM(x)}
            className={`shrink-0 rounded-full px-3 py-1 text-xs font-bold ${m === x ? "bg-[var(--lime)] text-black" : "bg-white/5 text-white/70"}`}
          >
            {x === "all" ? "همه" : muscleName(x)}
          </button>
        ))}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        {filtered.map((e) => (
          <button key={e.id} className="overflow-hidden rounded-2xl text-right" onClick={() => setOpen(e)}>
            <div className="exercise-media">
              <img src={e.image} alt={e.nameFa} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              <div className="absolute bottom-2 right-2 left-2">
                <div className="text-sm font-extrabold">{e.nameFa}</div>
                <div className="text-[10px] text-white/60">{muscleName(e.muscle)}</div>
              </div>
            </div>
          </button>
        ))}
      </div>
      {open && (
        <div className="modal-layer fixed inset-0 z-50 overflow-y-auto bg-black/70 p-4" onClick={() => setOpen(null)}>
          <div className="card mx-auto max-w-sm overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="exercise-detail-media"><img src={open.image} alt="" /></div>
            <div className="p-4">
              <h3 className="text-lg font-extrabold">{open.nameFa}</h3>
              <p className="text-xs text-[var(--muted)]">{open.nameEn}</p>
              <ul className="mt-3 space-y-2 text-sm leading-6">
                {open.instructions.map((x) => (
                  <li key={x}>• {x}</li>
                ))}
              </ul>
              <p className="mt-3 text-xs text-[var(--gold)]">{open.tip}</p>
              <button className="btn btn-ghost mt-4 w-full" onClick={() => setOpen(null)}>
                بستن
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
