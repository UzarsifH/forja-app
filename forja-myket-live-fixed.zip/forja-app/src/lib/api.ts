/**
 * جایگزین سرور قبلی (Next.js API + PostgreSQL).
 * `apiFetch` همان شکل `fetch` را دارد و همان خروجی‌ها را می‌دهد،
 * اما همه‌چیز را روی خود گوشی انجام می‌دهد؛ بنابراین اپ بدون اینترنت و بدون سرور کار می‌کند.
 */
import { APP_CONFIG } from "@/config";
import { FREE_SESSION, generatePlan } from "@/lib/coach";
import { getDb, nextId, nowIso, saveDb, type DB, type UserRow } from "@/lib/db";
import { EXERCISES } from "@/lib/exercises";
import type { MyketPurchase } from "@/lib/myket";
import type { AssessmentAnswers, MeUser } from "@/lib/types";
import {
  bmiOf,
  daysFromNow,
  hashPassword,
  isValidPhone,
  normalizePhone,
  randomHex,
  verifyPassword,
} from "@/lib/utils";

type Json = Record<string, unknown>;
type Body = Record<string, unknown> | null;
type Handler = (body: Body) => Promise<Json> | Json;

class HttpError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

const fail = (message: string, status = 400): never => {
  throw new HttpError(message, status);
};

/* ───────────── کمکی‌ها ───────────── */

function toMe(db: DB, user: UserRow): MeUser {
  const now = Date.now();
  const active = db.subscriptions
    .filter((s) => s.userId === user.id)
    .sort((a, b) => b.id - a.id)
    .find((s) => s.status === "active" && s.expiresAt && new Date(s.expiresAt).getTime() > now);
  return {
    id: user.id,
    phone: user.phone,
    name: user.name,
    createdAt: user.createdAt,
    isPremium: Boolean(active),
    premiumUntil: active?.expiresAt ?? null,
    hasPlan: db.workoutPlans.some((p) => p.userId === user.id),
    hasAssessment: db.assessments.some((a) => a.userId === user.id),
  };
}

function currentUser(db: DB): UserRow | null {
  if (db.currentUserId == null) return null;
  return db.users.find((u) => u.id === db.currentUserId) ?? null;
}

function requireUser(db: DB): { row: UserRow; me: MeUser } {
  const row = currentUser(db);
  if (!row) return fail("وارد حساب شو", 401);
  return { row, me: toMe(db, row) };
}

const num = (v: unknown, fallback = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
};

/* ───────────── مسیرها ───────────── */

const routes: Record<string, Handler> = {
  /* --- حساب کاربری --- */
  "GET /auth/me": () => {
    const db = getDb();
    const row = currentUser(db);
    if (!row) return { user: null };
    row.lastSeenAt = nowIso();
    saveDb();
    return { user: toMe(db, row) };
  },

  "POST /auth/register": async (body) => {
    const db = getDb();
    const phone = normalizePhone(String(body?.phone ?? ""));
    const password = String(body?.password ?? "");
    const name = String(body?.name ?? "").trim().slice(0, 40) || null;
    if (!isValidPhone(phone)) return fail("شماره موبایل معتبر نیست");
    if (password.length < 6) return fail("رمز عبور حداقل ۶ کاراکتر باشد");
    if (db.users.some((u) => u.phone === phone)) return fail("این شماره قبلاً ثبت شده. وارد شو.");

    const row: UserRow = {
      id: nextId(db),
      phone,
      passwordHash: await hashPassword(password),
      name,
      createdAt: nowIso(),
      lastSeenAt: nowIso(),
    };
    db.users.push(row);
    db.currentUserId = row.id;
    saveDb();
    return { user: { id: row.id, phone: row.phone, name: row.name } };
  },

  "POST /auth/login": async (body) => {
    const db = getDb();
    const phone = normalizePhone(String(body?.phone ?? ""));
    const password = String(body?.password ?? "");
    if (!isValidPhone(phone)) return fail("شماره موبایل معتبر نیست");
    const row = db.users.find((u) => u.phone === phone);
    if (!row || !(await verifyPassword(password, row.passwordHash))) {
      return fail("شماره یا رمز اشتباه است", 401);
    }
    row.lastSeenAt = nowIso();
    db.currentUserId = row.id;
    saveDb();
    return { user: { id: row.id, phone: row.phone, name: row.name } };
  },

  "POST /auth/logout": () => {
    const db = getDb();
    db.currentUserId = null;
    saveDb();
    return {};
  },

  /* --- تنظیمات --- */
  "GET /config": () => ({
    monthlyPrice: APP_CONFIG.monthlyPrice,
    paymentMode: APP_CONFIG.paymentMode,
    sku: APP_CONFIG.sku,
    packageName: APP_CONFIG.packageName,
    hasRsa: Boolean(APP_CONFIG.rsaPublicKey),
    appName: APP_CONFIG.appName,
  }),

  /* --- دانشنامه حرکات --- */
  "GET /exercises": () => {
    const logged = Boolean(currentUser(getDb()));
    return {
      exercises: EXERCISES.map((e) => ({
        id: e.id,
        nameFa: e.nameFa,
        nameEn: e.nameEn,
        muscle: e.muscle,
        level: e.level,
        image: e.image,
        equipment: e.equipment,
        instructions: logged ? e.instructions : e.instructions.slice(0, 1),
        tip: logged ? e.tip : "برای دیدن نکات مربی وارد شو",
      })),
    };
  },

  /* --- ارزیابی و برنامه --- */
  "GET /assessment": () => {
    const db = getDb();
    const { row } = requireUser(db);
    const list = db.assessments.filter((a) => a.userId === row.id).sort((a, b) => b.id - a.id);
    return { assessment: list[0] ?? null };
  },

  "POST /assessment": (body) => {
    const db = getDb();
    const { row, me } = requireUser(db);
    if (!me.isPremium) return fail("برای دریافت برنامه اختصاصی باید اشتراک فعال داشته باشی", 403);
    if (!body) return fail("پاسخ‌ها ناقص است");

    const answers = { ...(body as unknown as AssessmentAnswers) };
    const height = num(answers.height);
    const weight = num(answers.weight);
    if (!height || !weight || height < 120 || height > 230 || weight < 35 || weight > 220) {
      return fail("قد یا وزن معتبر نیست");
    }
    answers.height = height;
    answers.weight = weight;

    const required = [
      "gender", "age", "goal", "experience", "days", "duration", "focus",
      "equipment", "injury", "style", "intensity", "activity", "sleep", "cardio", "weak",
    ] as const;
    for (const key of required) {
      if (!answers[key]) return fail("همه سوال‌ها را جواب بده");
    }
    if (!Array.isArray(answers.priority) || answers.priority.length === 0) {
      answers.priority = ["chest", "back"];
    }

    const plan = generatePlan(answers);
    db.assessments.push({
      id: nextId(db),
      userId: row.id,
      answers,
      height,
      weight,
      bmi: bmiOf(height, weight),
      createdAt: nowIso(),
    });
    const planId = nextId(db);
    db.workoutPlans.push({
      id: planId,
      userId: row.id,
      title: plan.title,
      summary: plan.subtitle,
      durationWeeks: plan.weeks,
      daysPerWeek: plan.daysPerWeek,
      plan,
      createdAt: nowIso(),
    });
    saveDb();
    return { planId, plan };
  },

  "GET /plan": () => {
    const db = getDb();
    const { row } = requireUser(db);
    const current = db.workoutPlans.filter((p) => p.userId === row.id).sort((a, b) => b.id - a.id)[0];
    if (!current) {
      return { plan: null, freeSession: FREE_SESSION, completions: [], logs: [] };
    }
    return {
      planId: current.id,
      plan: current.plan,
      createdAt: current.createdAt,
      completions: db.dayCompletions.filter((c) => c.planId === current.id && c.userId === row.id),
      logs: db.workoutLogs.filter((l) => l.planId === current.id && l.userId === row.id),
      freeSession: FREE_SESSION,
    };
  },

  /* --- پروفایل --- */
  "GET /profile": () => {
    const db = getDb();
    const { row, me } = requireUser(db);
    return {
      user: me,
      payments: db.payments.filter((p) => p.userId === row.id).sort((a, b) => b.id - a.id),
      subscriptions: db.subscriptions.filter((s) => s.userId === row.id).sort((a, b) => b.id - a.id),
    };
  },

  "POST /profile": (body) => {
    const db = getDb();
    const { row } = requireUser(db);
    const name = String(body?.name ?? "").trim().slice(0, 40);
    if (!name) return fail("نام را وارد کن");
    row.name = name;
    saveDb();
    return { name };
  },

  /* --- پیشرفت --- */
  "GET /progress": () => {
    const db = getDb();
    const { row } = requireUser(db);
    const weights = db.weightLogs.filter((w) => w.userId === row.id).sort((a, b) => b.id - a.id);
    const days = db.dayCompletions.filter((d) => d.userId === row.id).sort((a, b) => b.id - a.id);
    const logs = db.workoutLogs.filter((l) => l.userId === row.id);
    const badges = db.achievements.filter((a) => a.userId === row.id);
    const xp = days.reduce((s, d) => s + (d.xp ?? 0), 0);
    const calories = days.reduce((s, d) => s + (d.calories ?? 0), 0);
    return {
      weights,
      days,
      badges,
      stats: {
        xp,
        calories,
        workouts: days.length,
        exercises: logs.filter((l) => l.status === "completed").length,
        level: Math.max(1, Math.floor(xp / 250) + 1),
      },
    };
  },

  "POST /progress": (body) => {
    const db = getDb();
    const { row } = requireUser(db);
    const weight = num(String(body?.weight ?? "").replace(",", "."));
    if (!weight || weight < 30 || weight > 250) return fail("وزن معتبر نیست");
    db.weightLogs.push({
      id: nextId(db),
      userId: row.id,
      weight,
      note: body?.note ? String(body.note) : null,
      createdAt: nowIso(),
    });
    saveDb();
    return { saved: true };
  },

  /* --- ثبت تمرین --- */
  "POST /workout/log": (body) => {
    const db = getDb();
    const { row } = requireUser(db);
    if (!body || body.dayIndex === undefined || !body.exerciseId || !body.status) {
      return fail("داده ناقص");
    }
    const planId = num(body.planId);
    if (planId && !db.workoutPlans.some((p) => p.id === planId && p.userId === row.id)) {
      return fail("برنامه پیدا نشد", 404);
    }
    db.workoutLogs.push({
      id: nextId(db),
      userId: row.id,
      planId,
      dayIndex: num(body.dayIndex),
      exerciseId: String(body.exerciseId),
      status: String(body.status),
      setsDone: num(body.setsDone),
      durationSec: num(body.durationSec),
      createdAt: nowIso(),
    });
    saveDb();
    return { saved: true };
  },

  "PUT /workout/log": (body) => {
    const db = getDb();
    const { row } = requireUser(db);
    if (!body || body.dayIndex === undefined) return fail("داده ناقص");

    db.dayCompletions.push({
      id: nextId(db),
      userId: row.id,
      planId: num(body.planId),
      dayIndex: num(body.dayIndex),
      calories: num(body.calories),
      durationSec: num(body.durationSec),
      xp: body.xp === undefined ? 80 : num(body.xp, 80),
      completedAt: nowIso(),
    });

    // اصلاح باگ قدیمی: تعداد جلسه‌ها بعد از ثبت حساب می‌شود (قبلاً یکی اضافه شمرده می‌شد)
    const total = db.dayCompletions.filter((d) => d.userId === row.id).length;
    const have = new Set(db.achievements.filter((a) => a.userId === row.id).map((a) => a.code));
    const unlocks: { code: string; title: string }[] = [];
    if (!have.has("first_workout")) unlocks.push({ code: "first_workout", title: "اولین جلسه فورج شد" });
    if (total >= 7 && !have.has("week_warrior")) unlocks.push({ code: "week_warrior", title: "۷ جلسه کامل" });
    if (total >= 20 && !have.has("iron_will")) unlocks.push({ code: "iron_will", title: "اراده آهنی" });
    for (const u of unlocks) {
      db.achievements.push({ id: nextId(db), userId: row.id, code: u.code, title: u.title, unlockedAt: nowIso() });
    }
    saveDb();
    return { completed: true, unlocks };
  },

  /* --- پرداخت مایکت --- */
  "POST /payment/myket/init": () => {
    const db = getDb();
    const { row, me } = requireUser(db);
    if (me.isPremium) return fail("اشتراک فعال داری");

    const payload = `forja:${row.id}:${randomHex(8)}`;
    // اصلاح باگ قدیمی: هر بار باز کردن صفحه پرداخت یک ردیف «در انتظار» جدید می‌ساخت
    let pay = db.payments.find((p) => p.userId === row.id && p.status === "pending");
    if (pay) {
      pay.payload = payload;
      pay.amount = APP_CONFIG.monthlyPrice;
      pay.sku = APP_CONFIG.sku;
    } else {
      pay = {
        id: nextId(db),
        userId: row.id,
        amount: APP_CONFIG.monthlyPrice,
        status: "pending",
        gateway: "myket",
        sku: APP_CONFIG.sku,
        purchaseToken: null,
        orderId: null,
        payload,
        raw: null,
        createdAt: nowIso(),
      };
      db.payments.push(pay);
    }
    saveDb();
    return {
      paymentId: pay.id,
      amount: pay.amount,
      sku: APP_CONFIG.sku,
      payload,
      packageName: APP_CONFIG.packageName,
      rsaPublicKey: APP_CONFIG.rsaPublicKey,
      paymentMode: APP_CONFIG.paymentMode,
    };
  },

  "POST /payment/myket/verify": (body) => {
    const db = getDb();
    const { row } = requireUser(db);
    const paymentId = num(body?.paymentId);
    if (!paymentId) return fail("شناسه پرداخت نیست");
    const payment = db.payments.find((p) => p.id === paymentId && p.userId === row.id);
    if (!payment) return fail("پرداخت پیدا نشد");
    if (payment.status === "paid") return { already: true };

    const purchase = (body?.purchase ?? {}) as MyketPurchase;
    if (APP_CONFIG.paymentMode !== "live") return fail("پرداخت آزمایشی غیرفعال است");

    // هیچ رسید ساختگی، web-fallback یا orderId جعلی قابل قبول نیست.
    const token = purchase.purchaseToken;
    const productId = purchase.productId || purchase.sku;
    const purchaseState = String(purchase.purchaseState ?? "").toUpperCase();
    if (!token) return fail("رسید معتبر مایکت دریافت نشد");
    if (!productId || productId !== payment.sku) return fail("SKU با محصول مایکت یکی نیست");
    if (purchase.packageName && purchase.packageName !== APP_CONFIG.packageName) return fail("Package Name با برنامه یکی نیست");
    if (purchaseState && !["1", "PURCHASED", "0"].includes(purchaseState)) return fail("خرید در مایکت تأیید نشده است");
    if (purchase.developerPayload && purchase.developerPayload !== payment.payload) return fail("Payload خرید معتبر نیست");

    // یک purchaseToken نباید دوباره برای حساب دیگری مصرف شود.
    const tokenAlreadyUsed = db.payments.some((p) => p.id !== payment.id && p.purchaseToken === token);
    if (tokenAlreadyUsed) return fail("این رسید قبلاً استفاده شده است");

    const expires = daysFromNow(APP_CONFIG.subscriptionDays).toISOString();
    payment.status = "paid";
    payment.purchaseToken = purchase.purchaseToken;
    payment.orderId = purchase.orderId || null;
    payment.raw = purchase;

    db.subscriptions.push({
      id: nextId(db),
      userId: row.id,
      status: "active",
      plan: "monthly",
      amount: payment.amount,
      startedAt: nowIso(),
      expiresAt: expires,
      myketSku: payment.sku,
      myketToken: purchase.purchaseToken || null,
      myketOrderId: purchase.orderId || null,
      payload: payment.payload,
      createdAt: nowIso(),
    });
    saveDb();
    return { activated: true, expiresAt: expires };
  },
};

/* ───────────── نقطه ورود ───────────── */

function reply(data: Json, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

type FetchInit = { method?: string; headers?: unknown; body?: string | null };

export async function apiFetch(input: string, init: FetchInit = {}): Promise<Response> {
  const method = (init.method || "GET").toUpperCase();
  const path = input.split("?")[0].replace(/^\/api/, "");
  let body: Body = null;
  if (init.body) {
    try {
      body = JSON.parse(init.body) as Body;
    } catch {
      body = null;
    }
  }
  try {
    const handler = routes[`${method} ${path}`];
    if (!handler) return reply({ ok: false, error: "مسیر پیدا نشد" }, 404);
    const data = await handler(body);
    return reply({ ok: true, ...data });
  } catch (e) {
    if (e instanceof HttpError) return reply({ ok: false, error: e.message }, e.status);
    console.error("[forja] api error", e);
    return reply({ ok: false, error: "خطای غیرمنتظره. دوباره تلاش کن." }, 500);
  }
}
