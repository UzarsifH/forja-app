import type { AssessmentAnswers, WorkoutPlanData } from "@/lib/types";

/**
 * دیتابیس محلی اپ (به‌جای PostgreSQL قبلی).
 * همه چیز روی خود گوشی داخل localStorage ذخیره می‌شود.
 */

export type UserRow = {
  id: number;
  phone: string;
  passwordHash: string;
  name: string | null;
  createdAt: string;
  lastSeenAt: string | null;
};
export type SubscriptionRow = {
  id: number;
  userId: number;
  status: string;
  plan: string;
  amount: number;
  startedAt: string | null;
  expiresAt: string | null;
  myketSku: string | null;
  myketToken: string | null;
  myketOrderId: string | null;
  payload: string | null;
  createdAt: string;
};
export type PaymentRow = {
  id: number;
  userId: number;
  amount: number;
  status: string;
  gateway: string;
  sku: string | null;
  purchaseToken: string | null;
  orderId: string | null;
  payload: string | null;
  raw: unknown;
  createdAt: string;
};
export type AssessmentRow = {
  id: number;
  userId: number;
  answers: AssessmentAnswers;
  height: number;
  weight: number;
  bmi: number;
  createdAt: string;
};
export type PlanRow = {
  id: number;
  userId: number;
  title: string;
  summary: string | null;
  durationWeeks: number;
  daysPerWeek: number;
  plan: WorkoutPlanData;
  createdAt: string;
};
export type WorkoutLogRow = {
  id: number;
  userId: number;
  planId: number;
  dayIndex: number;
  exerciseId: string;
  status: string;
  setsDone: number;
  durationSec: number;
  createdAt: string;
};
export type DayCompletionRow = {
  id: number;
  userId: number;
  planId: number;
  dayIndex: number;
  calories: number;
  durationSec: number;
  xp: number;
  completedAt: string;
};
export type WeightLogRow = {
  id: number;
  userId: number;
  weight: number;
  note: string | null;
  createdAt: string;
};
export type AchievementRow = {
  id: number;
  userId: number;
  code: string;
  title: string;
  unlockedAt: string;
};

export type DB = {
  v: 1;
  seq: number;
  currentUserId: number | null;
  users: UserRow[];
  subscriptions: SubscriptionRow[];
  payments: PaymentRow[];
  assessments: AssessmentRow[];
  workoutPlans: PlanRow[];
  workoutLogs: WorkoutLogRow[];
  dayCompletions: DayCompletionRow[];
  weightLogs: WeightLogRow[];
  achievements: AchievementRow[];
};

const KEY = "forja_db_v1";

function emptyDb(): DB {
  return {
    v: 1,
    seq: 0,
    currentUserId: null,
    users: [],
    subscriptions: [],
    payments: [],
    assessments: [],
    workoutPlans: [],
    workoutLogs: [],
    dayCompletions: [],
    weightLogs: [],
    achievements: [],
  };
}

/* ذخیره‌سازی امن: اگر localStorage در دسترس نبود، موقتاً داخل حافظه نگه می‌دارد */
const memory = new Map<string, string>();

function readRaw(): string | null {
  try {
    return localStorage.getItem(KEY);
  } catch {
    return memory.get(KEY) ?? null;
  }
}

function writeRaw(value: string) {
  try {
    localStorage.setItem(KEY, value);
  } catch {
    memory.set(KEY, value);
  }
}

let cache: DB | null = null;

export function getDb(): DB {
  if (cache) return cache;
  const base = emptyDb();
  const raw = readRaw();
  if (raw) {
    try {
      const parsed = JSON.parse(raw) as Partial<DB>;
      cache = { ...base, ...parsed, v: 1 };
    } catch {
      // فایل خراب شده؛ یک نسخه پشتیبان نگه می‌داریم و از نو شروع می‌کنیم
      try {
        localStorage.setItem(`${KEY}_corrupt`, raw);
      } catch {
        /* ignore */
      }
      cache = base;
    }
  } else {
    cache = base;
  }
  return cache;
}

export function saveDb() {
  if (!cache) return;
  writeRaw(JSON.stringify(cache));
}

export function nextId(db: DB) {
  db.seq += 1;
  return db.seq;
}

export function nowIso() {
  return new Date().toISOString();
}
