import { IMG, MUSCLE_IMAGES } from "@/lib/media";
import type { Equipment, Exercise, Injury, Level, Muscle } from "@/lib/types";

function ex(
  id: string,
  nameFa: string,
  nameEn: string,
  muscle: Muscle,
  secondary: Muscle[],
  equipment: Equipment[],
  level: Level,
  avoid: Injury[],
  image: string,
  caloriesPerMin: number,
  defaultSets: number,
  defaultReps: string,
  restSec: number,
  instructions: string[],
  tip: string,
): Exercise {
  return {
    id,
    nameFa,
    nameEn,
    muscle,
    secondary,
    equipment,
    level,
    avoid,
    image,
    caloriesPerMin,
    defaultSets,
    defaultReps,
    restSec,
    instructions,
    tip,
  };
}

export const EXERCISES: Exercise[] = [
  ex("bench", "پرس سینه هالتر", "Barbell Bench Press", "chest", ["triceps", "shoulders"], ["gym"], "intermediate", ["shoulder", "wrist"], "/images/exercises/bench.svg", 8, 4, "6-10", 120, ["روی نیمکت دراز بکش، تیغه‌های کتف را جمع کن.", "هالتر را روی خط سینه پایین بیاور.", "منفجرانه پرس کن بدون قوس بیش از حد کمر."], "کف پا روی زمین و مچ در راستای ساعد بماند."),
  ex("incline_db", "پرس بالاسینه دمبل", "Incline Dumbbell Press", "chest", ["shoulders", "triceps"], ["gym", "dumbbell"], "beginner", ["shoulder"], "/images/exercises/incline_db.svg", 7, 3, "8-12", 90, ["نیمکت را روی ۳۰ تا ۴۵ درجه بگذار.", "دمبل‌ها را بالای سینه ببر.", "با کنترل پایین بیا و سینه را باز کن."], "زاویه زیاد، کار را به شانه می‌دهد."),
  ex("pushup", "شنا سوئدی", "Push-up", "chest", ["triceps", "core"], ["bodyweight", "gym", "dumbbell", "band"], "beginner", ["wrist", "shoulder"], "/images/exercises/pushup.svg", 7, 3, "10-20", 60, ["دست‌ها کمی بازتر از شانه.", "بدن مثل تخته یک‌دست.", "سینه را نزدیک زمین ببر و بالا بیا."], "باسن بالا نرود."),
  ex("chest_fly", "قفسه سینه دمبل", "Dumbbell Fly", "chest", ["shoulders"], ["gym", "dumbbell"], "intermediate", ["shoulder"], "/images/exercises/chest_fly.svg", 6, 3, "10-15", 75, ["دمبل‌ها را با آرنج نرم باز کن.", "کشش را روی سینه حس کن.", "مثل بغل کردن به هم برگرد."], "آرنج را قفل نکن."),
  ex("dips", "دیپ سینه", "Chest Dip", "chest", ["triceps"], ["gym"], "advanced", ["shoulder", "wrist"], "/images/exercises/dips.svg", 8, 3, "6-12", 90, ["تنه را کمی جلو بده.", "تا کشش سینه پایین برو.", "بدون تاب خوردن بالا بیا."], "اگر شانه درد گرفت عمق را کم کن."),
  ex("band_press", "پرس سینه با کش", "Band Chest Press", "chest", ["triceps"], ["band"], "beginner", ["shoulder"], "/images/exercises/band_press.svg", 6, 3, "12-18", 45, ["کش را پشت کمر یا به ستون ثابت ببند.", "پرس کن تا دست‌ها صاف شوند.", "با کنترل برگرد."], "کشش کش در انتهای حرکت حفظ شود."),

  ex("pulldown", "زیربغل سیم‌کش", "Lat Pulldown", "back", ["biceps"], ["gym"], "beginner", ["shoulder"], "/images/exercises/pulldown.svg", 7, 4, "8-12", 90, ["میله را کمی بیشتر از عرض شانه بگیر.", "سینه را بالا بده و میله را به بالای سینه بکش.", "لات را منقبض کن و آرام برگرد."], "با تاب بدن تقلب نکن."),
  ex("bb_row", "زیربغل هالتر خم", "Barbell Row", "back", ["biceps", "core"], ["gym"], "intermediate", ["back"], "/images/exercises/bb_row.svg", 8, 4, "6-10", 120, ["از لگن خم شو، کمر صاف.", "هالتر را به پایین شکم بکش.", "تیغه‌ها را به هم نزدیک کن."], "گردن را در راستای ستون فقرات نگه دار."),
  ex("seated_row", "زیربغل قایقی", "Seated Row", "back", ["biceps"], ["gym"], "beginner", ["back"], "/images/exercises/seated_row.svg", 6, 3, "8-12", 75, ["سینه را جلو بده.", "دستگیره را به سمت ناف بکش.", "مکث یک ثانیه‌ای و برگشت."], "شانه‌ها را داخل گوش نبر."),
  ex("pullup", "بارفیکس", "Pull-up", "back", ["biceps"], ["gym", "bodyweight"], "advanced", ["shoulder", "wrist"], "/images/exercises/pullup.svg", 9, 3, "5-10", 120, ["آویزان شو، کتف را پایین بده.", "سینه را به میله نزدیک کن.", "تا کشش کامل پایین برو."], "اگر سخت است از کش کمکی استفاده کن."),
  ex("superman", "سوپرمن", "Superman", "back", ["core"], ["bodyweight", "band", "dumbbell"], "beginner", [], "/images/exercises/superman.svg", 4, 3, "12-15", 45, ["روی شکم دراز بکش.", "دست و پا را همزمان بالا بیاور.", "۲ ثانیه نگه دار و پایین بیا."], "کمر را بیش از حد قوس نده."),
  ex("band_row", "پارویی با کش", "Band Row", "back", ["biceps"], ["band"], "beginner", [], "/images/exercises/band_row.svg", 5, 3, "12-18", 45, ["کش را به نقطه ثابت ببند.", "آرنج را نزدیک بدن بکش.", "تیغه کتف را جمع کن."], "قفسه سینه را باز نگه دار."),

  ex("ohp", "پرس شانه هالتر", "Overhead Press", "shoulders", ["triceps", "core"], ["gym"], "intermediate", ["shoulder", "back"], "/images/exercises/ohp.svg", 8, 4, "5-8", 120, ["هالتر روی جلوی شانه.", "بدون قوس کمر بالای سر ببر.", "با کنترل پایین بیا."], "باسن را قفل و شکم را سفت کن."),
  ex("db_press", "پرس شانه دمبل", "Dumbbell Shoulder Press", "shoulders", ["triceps"], ["gym", "dumbbell"], "beginner", ["shoulder"], "/images/exercises/db_press.svg", 7, 3, "8-12", 90, ["دمبل‌ها کنار گوش.", "بالا پرس کن تا نزدیک به هم شوند.", "آرنج را کمی جلوتر از بدن نگه دار."], "وزنه‌ای انتخاب کن که فرم خراب نشود."),
  ex("lateral", "نشر جانب", "Lateral Raise", "shoulders", [], ["gym", "dumbbell", "band"], "beginner", ["shoulder"], "/images/exercises/lateral.svg", 5, 3, "12-15", 60, ["دست‌ها کمی خم.", "تا خط شانه بالا ببر.", "آرام پایین بیا."], "تاب دادن تقلب است."),
  ex("rear_fly", "نشر خم", "Rear Delt Fly", "shoulders", ["back"], ["gym", "dumbbell", "band"], "beginner", [], "/images/exercises/rear_fly.svg", 5, 3, "12-15", 45, ["از لگن خم شو.", "دمبل‌ها را به طرفین باز کن.", "روی پشت شانه تمرکز کن."], "برای اصلاح قوز عالی است."),
  ex("face", "فیس پول", "Face Pull", "shoulders", ["back"], ["gym", "band"], "beginner", [], "/images/exercises/face.svg", 5, 3, "12-15", 45, ["کش یا کابل را هم‌سطح صورت ببند.", "دستگیره را به سمت پیشانی بکش و آرنج‌ها را بالا نگه دار.", "۱ ثانیه مکث کن و آرام برگرد."], "برای سلامت شانه و اصلاح قوز عالی است."),
  ex("pike_push", "شنا دست بالا", "Pike Push-up", "shoulders", ["triceps"], ["bodyweight"], "intermediate", ["wrist", "shoulder"], "/images/exercises/pike_push.svg", 7, 3, "8-12", 60, ["باسن را بالا ببر مثل V.", "سر را بین دست‌ها پایین ببر.", "شانه را پرس کن بالا."], "نگاه به پاها باشد نه جلو."),

  ex("curl", "جلوبازو هالتر", "Barbell Curl", "biceps", [], ["gym"], "beginner", ["wrist"], "/images/exercises/curl.svg", 5, 3, "8-12", 60, ["آرنج چسبیده به بدن.", "تا انقباض کامل بالا بیا.", "۳ ثانیه منفی پایین برو."], "شانه را جلو نده."),
  ex("hammer", "چکشی دمبل", "Hammer Curl", "biceps", [], ["gym", "dumbbell"], "beginner", ["wrist"], "/images/exercises/hammer.svg", 5, 3, "8-12", 60, ["دست‌ها چکشی.", "بدون تاب بالا بیا.", "انقباض بالای حرکت را حس کن."], "برای ضخامت بازو عالی است."),
  ex("band_curl", "جلوبازو با کش", "Band Curl", "biceps", [], ["band", "bodyweight"], "beginner", [], "/images/exercises/band_curl.svg", 4, 3, "12-20", 40, ["روی کش بایست.", "آرنج ثابت، بالا بکش.", "آهسته برگرد."], "در بالا ۱ ثانیه مکث کن."),

  ex("pushdown", "پشت‌بازو سیم‌کش", "Triceps Pushdown", "triceps", [], ["gym"], "beginner", ["wrist"], "/images/exercises/pushdown.svg", 5, 3, "10-15", 45, ["آرنج چسبیده به پهلو.", "تا صاف شدن دست پایین بده.", "فقط ساعد حرکت کند."], "شانه را درگیر نکن."),
  ex("skull", "پشت‌بازو خوابیده", "Skull Crusher", "triceps", [], ["gym", "dumbbell"], "intermediate", ["wrist"], "/images/exercises/skull.svg", 6, 3, "8-12", 75, ["دمبل را به سمت پیشانی پایین بیاور.", "آرنج را ثابت نگه دار.", "بالا پرس کن."], "وزن را کنترل کن."),
  ex("bench_dip", "دیپ روی نیمکت", "Bench Dip", "triceps", ["chest"], ["bodyweight", "gym", "dumbbell"], "beginner", ["shoulder", "wrist"], "/images/exercises/bench_dip.svg", 6, 3, "10-15", 45, ["دست‌ها روی لبه نیمکت.", "زانو خم، پایین برو.", "با پشت‌بازو بالا بیا."], "شانه‌ها را به گوش نزدیک نکن."),
  ex("oh_ext", "پشت‌بازو پشت سر", "Overhead Extension", "triceps", [], ["gym", "dumbbell", "band"], "beginner", ["shoulder"], "/images/exercises/oh_ext.svg", 5, 3, "10-15", 60, ["دمبل را پشت سر پایین ببر.", "آرنج رو به سقف.", "تا صاف شدن بالا برو."], "دنده‌ها را باز نگه دار."),

  ex("squat", "اسکوات هالتر", "Back Squat", "quads", ["glutes", "core"], ["gym"], "intermediate", ["knee", "back"], "/images/exercises/squat.svg", 9, 4, "5-8", 150, ["هالتر روی ذوزنقه، نه گردن.", "از لگن و زانو همزمان پایین.", "تا موازی یا کمی پایین‌تر، بعد بالا."], "زانو داخل نرود، کمر صاف."),
  ex("goblet", "گابلت اسکوات", "Goblet Squat", "quads", ["glutes", "core"], ["gym", "dumbbell"], "beginner", ["knee"], "/images/exercises/goblet.svg", 7, 3, "8-12", 75, ["دمبل را جلوی سینه بگیر.", "آرنج بین زانوها پایین برو.", "پاشنه روی زمین بماند."], "برای یادگیری اسکوات عالی است."),
  ex("lunge", "لانج", "Walking Lunge", "quads", ["glutes", "hamstrings"], ["gym", "dumbbell", "bodyweight"], "beginner", ["knee"], "/images/exercises/lunge.svg", 8, 3, "8-12 هر پا", 75, ["یک قدم بزرگ جلو.", "هر دو زانو حدود ۹۰ درجه.", "از پاشنه جلو بالا بیا."], "تنه را صاف نگه دار."),
  ex("leg_press", "پرس پا", "Leg Press", "quads", ["glutes"], ["gym"], "beginner", ["knee", "back"], "/images/exercises/leg_press.svg", 8, 4, "8-12", 90, ["پاها عرض شانه روی صفحه.", "تا ۹۰ درجه پایین.", "زانو را کامل قفل نکن."], "کمر چسبیده به پشتی بماند."),
  ex("split_squat", "اسکوات بلغاری", "Bulgarian Split Squat", "quads", ["glutes"], ["gym", "dumbbell", "bodyweight"], "intermediate", ["knee"], "/images/exercises/split_squat.svg", 8, 3, "8-10 هر پا", 75, ["پای عقب روی نیمکت.", "تنه کمی جلو.", "زانوی جلو را کنترل‌شده پایین ببر."], "وزن روی پای جلو باشد."),
  ex("bw_squat", "اسکوات وزن بدن", "Bodyweight Squat", "quads", ["glutes"], ["bodyweight", "band"], "beginner", ["knee"], "/images/exercises/bw_squat.svg", 6, 3, "15-20", 45, ["پاها کمی باز.", "باسن عقب، سینه بالا.", "تا موازی پایین و بالا."], "زانوها جهت پنجه باشند."),

  ex("rdl", "ددلیفت رومانیایی", "Romanian Deadlift", "hamstrings", ["glutes", "back"], ["gym", "dumbbell"], "intermediate", ["back"], "/images/exercises/rdl.svg", 8, 3, "8-12", 90, ["زانو نرم، از لگن خم شو.", "وزنه نزدیک ساق پایین برود.", "همسترینگ کش بیاید، بعد باسن را قفل کن."], "کمر گرد نشود."),
  ex("hip_hinge", "hinge باسن", "Good Morning / Hip Hinge", "hamstrings", ["glutes", "back"], ["bodyweight", "band", "gym"], "beginner", ["back"], "/images/exercises/hip_hinge.svg", 5, 3, "10-15", 60, ["دست روی سینه یا پشت سر.", "از لگن خم شو تا تنه موازی.", "باسن را فشار بده بالا."], "زانو را زیاد خم نکن."),
  ex("leg_curl", "پشت پا دستگاه", "Leg Curl", "hamstrings", [], ["gym"], "beginner", ["knee"], "/images/exercises/leg_curl.svg", 5, 3, "10-15", 60, ["لگن روی نیمکت بچسبد.", "پاشنه را به باسن نزدیک کن.", "آرام باز کن."], "در بالا باسن را بلند نکن."),

  ex("thrust", "هیپ تراست", "Hip Thrust", "glutes", ["hamstrings"], ["gym", "dumbbell"], "beginner", [], "/images/exercises/thrust.svg", 7, 4, "8-12", 75, ["تیغه کتف روی نیمکت.", "هالتر یا دمبل روی لگن.", "باسن را تا خط شانه بالا ببر و ۱ ثانیه بفشار."], "چانه را نزدیک سینه نگه دار."),
  ex("bridge", "بریج باسن", "Glute Bridge", "glutes", ["hamstrings", "core"], ["bodyweight", "band", "dumbbell"], "beginner", [], "/images/exercises/bridge.svg", 5, 3, "12-20", 45, ["به پشت، زانو خم.", "باسن را بالا ببر.", "۱ ثانیه فشار و پایین."], "از کمر هل نده، از باسن هل بده."),
  ex("kickback", "کیک‌بک", "Glute Kickback", "glutes", [], ["band", "bodyweight", "gym"], "beginner", [], "/images/exercises/kickback.svg", 5, 3, "12-15 هر پا", 40, ["چهار دست و پا یا ایستاده با کش.", "پا را عقب و بالا ببر.", "باسن را منقبض کن."], "کمر قوس اضافه نگیرد."),

  ex("calf", "ساق ایستاده", "Standing Calf Raise", "calves", [], ["gym", "dumbbell", "bodyweight"], "beginner", [], "/images/exercises/calf.svg", 4, 4, "12-20", 40, ["روی پنجه بالا برو.", "۱ ثانیه مکث.", "پاشنه را کامل پایین ببر."], "نوسان نده، دامنه کامل."),
  ex("seated_calf", "ساق نشسته", "Seated Calf Raise", "calves", [], ["gym"], "beginner", [], "/images/exercises/seated_calf.svg", 4, 3, "12-20", 40, ["زانو ۹۰ درجه.", "پاشنه را بالا ببر.", "کشش در پایین."], "سولئوس را هدف می‌گیرد."),

  ex("plank", "پلانک", "Plank", "core", [], ["bodyweight", "gym", "dumbbell", "band"], "beginner", [], "/images/exercises/plank.svg", 4, 3, "30-60ث", 30, ["آرنج زیر شانه.", "بدن یک خط.", "باسن نه بالا نه پایین."], "نفس را حبس نکن."),
  ex("deadbug", "ددباگ", "Dead Bug", "core", [], ["bodyweight", "band"], "beginner", ["back"], "/images/exercises/deadbug.svg", 4, 3, "8-12 هر سمت", 30, ["کمر چسبیده به زمین.", "دست و پای مخالف را باز کن.", "بدون بلند شدن کمر برگرد."], "حرکت را آرام انجام بده."),
  ex("hanging_knee", "بالا آوردن زانو آویزان", "Hanging Knee Raise", "core", [], ["gym"], "intermediate", ["wrist", "shoulder"], "/images/exercises/hanging_knee.svg", 6, 3, "8-15", 45, ["شانه را پایین بده.", "زانوها را به سینه نزدیک کن.", "تاب نخور."], "اگر سخت است روی نیمکت انجام بده."),
  ex("bicycle", "دوچرخه شکم", "Bicycle Crunch", "core", [], ["bodyweight"], "beginner", [], "/images/exercises/bicycle.svg", 5, 3, "16-24", 30, ["آرنج به زانوی مخالف.", "شانه از زمین جدا شود.", "ریتم کنترل‌شده."], "دست را پشت سر نکش."),
  ex("bird_dog", "برد داگ", "Bird Dog", "core", ["back"], ["bodyweight"], "beginner", [], "/images/exercises/bird_dog.svg", 4, 3, "8-10 هر سمت", 30, ["چهار دست و پا.", "دست و پای مخالف را صاف کن.", "۲ ثانیه تعادل."], "لگن نچرخد."),

  ex("walk", "پیاده‌روی شیب‌دار", "Incline Walk", "full", ["core"], ["gym", "bodyweight"], "beginner", ["knee"], "/images/exercises/walk.svg", 8, 1, "10-20دقیقه", 0, ["شیب ۵ تا ۱۰ درصد.", "قدم سریع نه دویدن.", "دست‌ها طبیعی تاب بخورند."], "بهترین کاردیو برای حفظ عضله."),
  ex("bike", "دوچرخه ثابت", "Stationary Bike", "full", ["quads"], ["gym"], "beginner", ["knee"], "/images/exercises/bike.svg", 8, 1, "10-15دقیقه", 0, ["مقاومت متوسط.", "ریتم یکنواخت.", "زانو قفل نشود."], "برای زانو معمولاً امن‌تر از دویدن است."),
  ex("jump_rope", "طناب", "Jump Rope", "full", ["calves"], ["bodyweight", "gym"], "intermediate", ["knee"], "/images/exercises/jump_rope.svg", 10, 3, "45-60ث", 30, ["پرشی کوتاه روی پنجه.", "مچ آرام.", "نفس را قطع نکن."], "اگر زانو درد دارد حذف شود."),
  ex("mountain", "کوهنورد", "Mountain Climber", "core", ["full"], ["bodyweight"], "beginner", ["wrist"], "/images/exercises/mountain.svg", 9, 3, "30-45ث", 30, ["وضعیت پلانک.", "زانوها یکی‌یکی جلو.", "باسن بالا نرود."], "کیفیت مهم‌تر از سرعت است."),
  ex("burpee", "برپی", "Burpee", "full", ["chest", "core"], ["bodyweight"], "advanced", ["wrist", "knee", "back"], "/images/exercises/burpee.svg", 12, 3, "8-12", 45, ["اسکوات، پلانک، شنا، پرش.", "حرکت را بشکن اگر خسته‌ای.", "فرم را فدای سرعت نکن."], "برای چربی‌سوزی قوی است."),
  ex("farmer", "حمل کشاورز", "Farmer Carry", "full", ["core", "shoulders"], ["gym", "dumbbell"], "beginner", [], "/images/exercises/farmer.svg", 7, 3, "30-40م", 45, ["دمبل سنگین در دو دست.", "سینه باز، قدم‌های کوتاه.", "شانه‌ها پایین."], "قدرت عملکردی عالی."),
];

export function muscleName(m: string) {
  const map: Record<string, string> = {
    chest: "سینه",
    back: "پشت",
    shoulders: "شانه",
    biceps: "جلو بازو",
    triceps: "پشت بازو",
    quads: "چهارسر",
    hamstrings: "همسترینگ",
    glutes: "باسن",
    calves: "ساق",
    core: "میان‌تنه",
    full: "کل بدن",
    arms: "بازو",
    legs: "پا",
  };
  return map[m] ?? m;
}

export function filterExercises(opts: {
  equipment: Equipment | "gym" | "dumbbell" | "bodyweight" | "band";
  injury: Injury | string;
  level: Level | string;
  muscle?: Muscle | string;
}) {
  const eq = opts.equipment;
  const injury = opts.injury as Injury;
  const level = opts.level as Level;
  return EXERCISES.filter((e) => {
    if (!e.equipment.includes(eq as Equipment) && eq !== "gym") {
      if (eq === "dumbbell" && !e.equipment.includes("dumbbell") && !e.equipment.includes("bodyweight")) return false;
      if (eq === "bodyweight" && !e.equipment.includes("bodyweight")) return false;
      if (eq === "band" && !e.equipment.includes("band") && !e.equipment.includes("bodyweight")) return false;
    }
    if (eq === "gym" && !e.equipment.includes("gym") && !e.equipment.includes("dumbbell") && !e.equipment.includes("bodyweight")) {
      return false;
    }
    if (injury && injury !== "none" && e.avoid.includes(injury as Injury)) return false;
    if (level === "beginner" && e.level === "advanced") return false;
    if (opts.muscle && e.muscle !== opts.muscle && !e.secondary.includes(opts.muscle as Muscle)) return false;
    return true;
  });
}
