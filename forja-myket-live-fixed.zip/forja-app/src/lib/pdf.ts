/**
 * ساخت PDF از برگه‌ی برنامه (داخل اپ، بدون چاپگر).
 * هر بلوک با data-pdf-block علامت‌گذاری شده و جداگانه رندر می‌شود تا صفحه‌ها وسط جدول نشکنند.
 */
import { Capacitor } from "@capacitor/core";
import { Directory, Filesystem } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";

const PAGE_BG = "#f6f1e8";

export async function exportPlanPdf(root: HTMLElement, fileName = "forja-plan.pdf") {
  const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import("html2canvas-pro"), import("jspdf")]);

  const blocks = Array.from(root.querySelectorAll<HTMLElement>("[data-pdf-block]"));
  if (blocks.length === 0) throw new Error("چیزی برای ساخت PDF پیدا نشد");

  // صبر می‌کنیم فونت‌ها کامل لود شوند تا متن فارسی درست رندر شود
  try {
    await document.fonts?.ready;
  } catch {
    /* ignore */
  }

  const doc = new jsPDF({ unit: "pt", format: "a4", compress: true });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 24;
  const gap = 10;
  const usableW = pageW - margin * 2;
  const usableH = pageH - margin * 2;

  const paintPage = () => {
    doc.setFillColor(PAGE_BG);
    doc.rect(0, 0, pageW, pageH, "F");
  };
  paintPage();
  let y = margin;

  for (const el of blocks) {
    const canvas = await html2canvas(el, {
      scale: 2,
      backgroundColor: PAGE_BG,
      useCORS: true,
      logging: false,
    });
    let w = usableW;
    let h = (canvas.height * w) / canvas.width;
    if (h > usableH) {
      // بلوک خیلی بلند: به اندازه‌ی صفحه کوچک می‌شود
      const k = usableH / h;
      h = usableH;
      w = w * k;
    }
    if (y + h > pageH - margin && y > margin) {
      doc.addPage();
      paintPage();
      y = margin;
    }
    const x = margin + (usableW - w) / 2;
    doc.addImage(canvas.toDataURL("image/jpeg", 0.92), "JPEG", x, y, w, h);
    y += h + gap;
  }

  if (Capacitor.isNativePlatform()) {
    const dataUri = doc.output("datauristring");
    const base64 = dataUri.slice(dataUri.indexOf(",") + 1);
    const saved = await Filesystem.writeFile({ path: fileName, data: base64, directory: Directory.Cache });
    await Share.share({
      title: "برنامه تمرینی فُرجا",
      dialogTitle: "ذخیره یا ارسال PDF برنامه",
      url: saved.uri,
    });
  } else {
    doc.save(fileName);
  }
}
