import { EXERCISES, filterExercises, muscleName } from "@/lib/exercises";
import type {
  AssessmentAnswers,
  Exercise,
  PlannedDay,
  PlannedExercise,
  WorkoutPlanData,
} from "@/lib/types";
import { ageFromRange, bmiLabel, bmiOf, calcBmr } from "@/lib/utils";

const GOAL_FA: Record<string, string> = {
  fatloss: "چربی‌سوزی هوشمند",
  muscle: "عضله‌سازی اصولی",
  strength: "قدرت و رکورد",
  recomp: "فرم‌دهی و بازترکیب",
  endurance: "استقامت و توان",
};

const SPLIT_NAME: Record<string, string> = {
  "full-3": "فول‌بادی چرخشی A/B/C",
  "ul-4": "آپر / لوور",
  "ppl-5": "پوش / پول / لِگ + تمرکز",
  "ppl-6": "پوش / پول / لِگ دو بار در هفته",
  "upper-bias": "اسپلیت با تمرکز بالاتنه",
  "lower-bias": "اسپلیت با تمرکز پایین‌تنه",
};


/** گزینه «بازو» در ارزیابی باید جلو بازو و پشت بازو را هم شامل شود */
function isPriorityMuscle(priority: string[] | undefined, muscle: string) {
  if (!priority) return false;
  if (priority.includes(muscle)) return true;
  if (priority.includes("arms") && (muscle === "biceps" || muscle === "triceps")) return true;
  return false;
}

function pick(list: Exercise[], id: string) {
  return list.find((e) => e.id === id) ?? null;
}

function takeUnique(
  pool: Exercise[],
  count: number,
  used: Set<string>,
  prefer?: string[],
) {
  const out: Exercise[] = [];
  if (prefer) {
    for (const id of prefer) {
      const found = pool.find((e) => e.id === id && !used.has(e.id));
      if (found) {
        out.push(found);
        used.add(found.id);
      }
      if (out.length >= count) return out;
    }
  }
  const sorted = [...pool].sort((a, b) => {
    const order = { beginner: 0, intermediate: 1, advanced: 2 };
    return order[a.level] - order[b.level];
  });
  for (const e of sorted) {
    if (used.has(e.id)) continue;
    out.push(e);
    used.add(e.id);
    if (out.length >= count) break;
  }
  return out;
}

function toPlanned(e: Exercise, sets: number, reps: string, rest: number, rpe: number, notes: string): PlannedExercise {
  return {
    id: e.id,
    nameFa: e.nameFa,
    nameEn: e.nameEn,
    muscle: e.muscle,
    muscleFa: muscleName(e.muscle),
    image: e.image,
    sets,
    reps,
    restSec: rest,
    rpe,
    notes,
    instructions: e.instructions,
    tip: e.tip,
  };
}

function progression(week: number, goal: string, intensity: string, experience: string) {
  const hard = intensity === "hardcore" ? 1 : intensity === "easy" ? -1 : 0;
  let setsAdd = week >= 3 ? 1 : 0;
  if (experience === "beginner") setsAdd = Math.min(setsAdd, 0);
  let rpe = 7 + (week - 1) + hard;
  if (experience === "beginner") rpe -= 1;
  rpe = Math.max(6, Math.min(9, rpe));

  let reps = "8-12";
  let rest = 75;
  if (goal === "strength") {
    reps = week >= 3 ? "4-6" : "5-8";
    rest = 150;
  } else if (goal === "fatloss" || goal === "endurance") {
    reps = week >= 3 ? "12-15" : "10-15";
    rest = 45;
  } else if (goal === "muscle") {
    reps = week >= 3 ? "6-10" : "8-12";
    rest = 90;
  } else {
    reps = "8-12";
    rest = 70;
  }
  if (intensity === "hardcore") rest = Math.max(40, rest - 15);
  return { setsAdd, rpe, reps, rest };
}

function sessionSize(duration: string, experience: string) {
  const d = Number(duration);
  let n = d <= 30 ? 4 : d <= 45 ? 5 : d <= 60 ? 6 : 8;
  if (experience === "beginner") n = Math.min(n, 5);
  return n;
}

function dayTemplate(
  focusKey: string,
  pool: Exercise[],
  answers: AssessmentAnswers,
): string[] {
  const p = answers.priority || [];
  const weak = answers.weak;
  const map: Record<string, string[]> = {
    fullA: ["squat", "bench", "bb_row", "ohp", "rdl", "plank", "calf"],
    fullB: ["goblet", "incline_db", "seated_row", "db_press", "lunge", "hammer", "deadbug"],
    fullC: ["split_squat", "pushup", "pulldown", "lateral", "thrust", "pushdown", "bird_dog"],
    upper: ["bench", "pulldown", "ohp", "seated_row", "incline_db", "lateral", "curl", "pushdown"],
    lower: ["squat", "rdl", "lunge", "thrust", "leg_press", "leg_curl", "calf", "plank"],
    push: ["bench", "ohp", "incline_db", "dips", "lateral", "pushdown", "chest_fly"],
    pull: ["pulldown", "bb_row", "seated_row", "rear_fly", "hammer", "curl", "face"],
    legs: ["squat", "rdl", "leg_press", "thrust", "lunge", "leg_curl", "calf"],
    core: ["deadbug", "plank", "hanging_knee", "bird_dog", "bicycle", "farmer"],
  };

  const homeMap: Record<string, string[]> = {
    fullA: ["bw_squat", "pushup", "band_row", "pike_push", "bridge", "plank", "calf"],
    fullB: ["split_squat", "pike_push", "superman", "lunge", "bench_dip", "deadbug", "kickback"],
    fullC: ["goblet", "pushup", "band_row", "lateral", "bridge", "mountain", "bird_dog"],
    upper: ["pushup", "band_row", "pike_push", "superman", "bench_dip", "band_curl", "lateral"],
    lower: ["bw_squat", "hip_hinge", "lunge", "bridge", "split_squat", "kickback", "calf"],
    push: ["pushup", "pike_push", "bench_dip", "lateral", "oh_ext", "mountain"],
    pull: ["band_row", "superman", "rear_fly", "band_curl", "bird_dog"],
    legs: ["bw_squat", "lunge", "bridge", "hip_hinge", "split_squat", "calf"],
    core: ["plank", "deadbug", "bicycle", "bird_dog", "mountain"],
  };

  const gym = answers.equipment === "gym" || answers.equipment === "dumbbell";
  const source = gym ? map : homeMap;
  let ids = [...(source[focusKey] ?? source.fullA)];

  if (p.includes("chest")) ids = ["bench", "incline_db", "pushup", ...ids];
  if (p.includes("back")) ids = ["pulldown", "bb_row", "band_row", ...ids];
  if (p.includes("shoulders")) ids = ["ohp", "lateral", "db_press", ...ids];
  if (p.includes("arms")) ids = ["curl", "pushdown", "hammer", ...ids];
  if (p.includes("glutes")) ids = ["thrust", "bridge", "kickback", ...ids];
  if (p.includes("quads")) ids = ["squat", "goblet", "leg_press", ...ids];
  if (p.includes("hamstrings")) ids = ["rdl", "leg_curl", "hip_hinge", ...ids];
  if (p.includes("core")) ids = ["plank", "hanging_knee", "deadbug", ...ids];

  if (weak === "chest") ids.unshift("incline_db", "pushup");
  if (weak === "back") ids.unshift("seated_row", "band_row");
  if (weak === "legs") ids.unshift("goblet", "lunge");
  if (weak === "arms") ids.unshift("hammer", "oh_ext");
  if (weak === "core") ids.unshift("plank", "deadbug");
  if (weak === "posture") ids.unshift("rear_fly", "bird_dog", "band_row");

  return ids.filter((id) => pool.some((e) => e.id === id) || EXERCISES.some((e) => e.id === id));
}

function buildSession(
  title: string,
  focus: string,
  preferredIds: string[],
  pool: Exercise[],
  answers: AssessmentAnswers,
  week: number,
  index: number,
): PlannedDay {
  const size = sessionSize(answers.duration, answers.experience);
  const { setsAdd, rpe, reps, rest } = progression(week, answers.goal, answers.intensity, answers.experience);
  const used = new Set<string>();
  const chosen: Exercise[] = [];

  for (const id of preferredIds) {
    const e = pick(pool, id) || pick(EXERCISES, id);
    if (!e || used.has(e.id)) continue;
    if (!pool.some((p) => p.id === e.id) && answers.equipment !== "gym") continue;
    chosen.push(e);
    used.add(e.id);
    if (chosen.length >= size) break;
  }

  if (chosen.length < size) {
    chosen.push(...takeUnique(pool, size - chosen.length, used));
  }

  const baseSets = answers.experience === "advanced" ? 4 : 3;
  const exercises = chosen.map((e, i) => {
    const isMain = i < 2;
    const sets = Math.max(2, baseSets + setsAdd - (isMain ? 0 : 1) + (answers.intensity === "hardcore" && isMain ? 1 : 0));
    let localReps = e.defaultReps;
    if (answers.goal === "strength" && isMain) localReps = reps;
    else if (answers.style === "circuit") localReps = "12-15";
    else localReps = reps;
    const localRest = answers.style === "circuit" ? 30 : isMain ? rest : Math.max(40, rest - 20);
    const note =
      i === 0
        ? "حرکت اصلی روز. قبل از ست‌های کاری یک ست گرم‌کننده سبک بزن."
        : isPriorityMuscle(answers.priority, e.muscle)
          ? "اولویت انتخابی تو. روی ارتباط ذهن و عضله تمرکز کن."
          : e.tip;
    return toPlanned(e, sets, localReps, localRest, rpe, note);
  });

  if (answers.cardio === "yes" && answers.goal !== "strength") {
    const cardio = pool.find((e) => e.id === "walk") || pick(EXERCISES, "walk");
    if (cardio && !used.has(cardio.id)) {
      exercises.push(
        toPlanned(
          cardio,
          1,
          answers.goal === "fatloss" ? "12-18 دقیقه" : "8-12 دقیقه",
          0,
          6,
          "کاردیو کم‌شدت برای چربی‌سوزی بدون تخریب ریکاوری.",
        ),
      );
    }
  } else if (answers.cardio === "light" && week % 2 === 0) {
    const cardio = pool.find((e) => e.id === "bike") || pick(EXERCISES, "walk");
    if (cardio) {
      exercises.push(toPlanned(cardio, 1, "8-10 دقیقه", 0, 5, "کاردیو کوتاه فقط برای جریان خون."));
    }
  }

  const minutes = Number(answers.duration);
  const cal = Math.round(minutes * (answers.intensity === "hardcore" ? 9 : answers.intensity === "easy" ? 6 : 7.5));

  const warmup = [
    "۳ تا ۵ دقیقه حرکت نرم یا طناب سبک",
    "چرخش مفصل شانه، لگن و مچ",
    "یک ست خیلی سبک از حرکت اول",
  ];
  const cooldown = ["کشش عضله درگیر روز، ۳۰ ثانیه هر بخش", "تنفس دیافراگمی ۱ دقیقه", "آب و کمی نمک یا الکترولیت"];

  const coachNotes = [
    "امروز کیفیت تکرار مهم‌تر از وزنه است. اگر فرم خراب شد وزنه را کم کن.",
    "آخرین ست باید سخت باشد اما تکنیک نریزد. ۲ تکرار در ذخیره کافی است.",
    "بین ست‌ها راه برو، موبایل را زمین بگذار، روی عضله هدف فکر کن.",
    "اگر خواب دیشب ضعیف بوده، ۱۰ درصد از وزنه‌ها کم کن نه اینکه جلسه را حذف کنی.",
    "تمرکز امروز روی دامنه کامل حرکت است؛ نیمه نزن.",
  ];

  return {
    index,
    week,
    title,
    focus,
    isRest: false,
    durationMin: minutes,
    calories: cal,
    coachNote: coachNotes[index % coachNotes.length],
    warmup,
    exercises,
    cooldown,
  };
}

function restDay(index: number, week: number, answers: AssessmentAnswers): PlannedDay {
  const mobility = [
    "پیاده‌روی آرام ۲۰ تا ۳۰ دقیقه",
    "کشش فلکسور لگن و سینه",
    "فوم‌رول پشت و چهارسر",
    "تنفس ۴-۷-۸ قبل خواب",
  ];
  if (answers.sleep === "low") {
    mobility.unshift("امشب اولویت با خواب است؛ کافئین بعد از ساعت ۴ ننوش.");
  }
  return {
    index,
    week,
    title: "ریکاوری فعال",
    focus: "بازسازی",
    isRest: true,
    durationMin: 25,
    calories: 120,
    coachNote:
      "رشد عضله در تمرین ساخته نمی‌شود؛ در ریکاوری ساخته می‌شود. امروز بدن را تعمیر کن تا فردا سنگین‌تر بزنی.",
    warmup: ["نفس عمیق", "چرخش مفصل"],
    exercises: [],
    cooldown: mobility,
  };
}

function splitFor(answers: AssessmentAnswers) {
  const days = Number(answers.days);
  const focus = answers.focus;
  if (focus === "upper") return { key: "upper-bias", pattern: days <= 3 ? ["upper", "fullA", "upper"] : days === 4 ? ["upper", "lower", "upper", "upper"] : days === 5 ? ["push", "pull", "upper", "lower", "push"] : ["push", "pull", "legs", "push", "pull", "upper"] };
  if (focus === "lower") return { key: "lower-bias", pattern: days <= 3 ? ["lower", "fullA", "legs"] : days === 4 ? ["lower", "upper", "legs", "lower"] : days === 5 ? ["legs", "push", "legs", "pull", "lower"] : ["legs", "push", "legs", "pull", "lower", "core"] };
  if (focus === "push") return { key: "upper-bias", pattern: days <= 3 ? ["push", "pull", "legs"] : days === 4 ? ["push", "pull", "legs", "push"] : ["push", "pull", "legs", "push", "pull"] };
  if (focus === "core") return { key: "full-3", pattern: days <= 3 ? ["fullA", "core", "fullB"] : days === 4 ? ["fullA", "core", "fullB", "core"] : ["push", "pull", "core", "legs", "core"] };
  if (days <= 3) return { key: "full-3", pattern: ["fullA", "fullB", "fullC"] };
  if (days === 4) return { key: "ul-4", pattern: ["upper", "lower", "upper", "lower"] };
  if (days === 5) return { key: "ppl-5", pattern: ["push", "pull", "legs", "upper", "lower"] };
  return { key: "ppl-6", pattern: ["push", "pull", "legs", "push", "pull", "legs"] };
}

const FOCUS_FA: Record<string, string> = {
  fullA: "فول‌بادی A",
  fullB: "فول‌بادی B",
  fullC: "فول‌بادی C",
  upper: "بالاتنه",
  lower: "پایین‌تنه",
  push: "پوش",
  pull: "پول",
  legs: "پا",
  core: "مرکز بدن",
};

export function generatePlan(answers: AssessmentAnswers): WorkoutPlanData {
  const height = Number(answers.height);
  const weight = Number(answers.weight);
  const bmi = bmiOf(height, weight);
  const age = ageFromRange(answers.age);
  const bmr = calcBmr(answers.gender, weight, height, age);
  const activityMul: Record<string, number> = {
    sedentary: 1.2,
    light: 1.35,
    moderate: 1.5,
    high: 1.7,
  };
  const tdee = Math.round(bmr * (activityMul[answers.activity] ?? 1.35));
  let calorie = tdee;
  if (answers.goal === "fatloss") calorie = tdee - 400;
  if (answers.goal === "muscle") calorie = tdee + 250;
  if (answers.goal === "recomp") calorie = tdee - 150;
  if (answers.goal === "strength") calorie = tdee + 150;

  const protein = Math.round(weight * (answers.goal === "fatloss" ? 2.0 : 1.8));
  const pool = filterExercises({
    equipment: answers.equipment as "gym",
    injury: answers.injury,
    level: answers.experience,
  });

  const split = splitFor(answers);
  const trainDays = Number(answers.days);
  const days: PlannedDay[] = [];
  let cursor = 0;

  for (let week = 1; week <= 4; week++) {
    const weekPattern = [...split.pattern];
    const slots = [false, false, false, false, false, false, false];
    if (trainDays === 3) {
      slots[0] = slots[2] = slots[4] = true;
    } else if (trainDays === 4) {
      slots[0] = slots[1] = slots[3] = slots[5] = true;
    } else if (trainDays === 5) {
      slots[0] = slots[1] = slots[2] = slots[4] = slots[5] = true;
    } else {
      slots[0] = slots[1] = slots[2] = slots[3] = slots[4] = slots[5] = true;
    }

    let p = 0;
    for (let d = 0; d < 7; d++) {
      if (slots[d]) {
        const key = weekPattern[p % weekPattern.length];
        p += 1;
        const ids = dayTemplate(key, pool, answers);
        days.push(
          buildSession(
            `هفته ${week} · ${FOCUS_FA[key] ?? key}`,
            FOCUS_FA[key] ?? key,
            ids,
            pool.length ? pool : EXERCISES,
            answers,
            week,
            cursor,
          ),
        );
      } else {
        days.push(restDay(cursor, week, answers));
      }
      cursor += 1;
    }
  }

  const nutritionTips = [
    `حدود ${calorie} کیلوکالری در روز هدف‌گذاری کن (برآورد مربی).`,
    `پروتئین روزانه حدود ${protein} گرم؛ هر وعده ۲۰ تا ۴۰ گرم.`,
    answers.goal === "fatloss"
      ? "کربوهیدرات را اطراف تمرین نگه دار و شب‌ها حجم غذا را کنترل کن."
      : "برای رشد، وعده بعد تمرین را حذف نکن؛ برنج، سیب‌زمینی یا نان سنگک با پروتئین.",
    "آب را به ۳ تا ۴ لیتر نزدیک کن. ادرار باید روشن باشد.",
    answers.sleep === "low"
      ? "با این خواب، رشد محدود است. حداقل ۷ ساعت را هدف بگیر."
      : "خوابت خوب است؛ همین را حفظ کن تا پیشرفت پایدار بماند.",
  ];

  const rules = [
    "هر هفته ۲.۵ تا ۵ درصد به وزنه اصلی اضافه کن اگر همه تکرارها تمیز زده شد.",
    "درد تیز مفصل یعنی توقف. درد عضلانی معمولی یعنی ادامه.",
    "اگر یک جلسه از دست رفت، برنامه را جابه‌جا نکن؛ از روز بعدی ادامه بده.",
    "هفته چهارم کمی سخت‌تر است. هفته بعد می‌توانی تکرار ارزیابی کنی.",
    "فرم > وزنه > تعداد. همیشه به همین ترتیب.",
  ];

  let estimated = "حفظ وزن با بهبود ترکیب بدن";
  if (answers.goal === "fatloss") estimated = "حدود ۲ تا ۴ کیلو کاهش در ۴ هفته با حفظ عضله";
  if (answers.goal === "muscle") estimated = "افزایش حجم و ۰.۵ تا ۲ کیلو وزن عضلانی در ۴ هفته";
  if (answers.goal === "strength") estimated = "رشد قدرت روی حرکات اصلی ۱۰ تا ۲۰ درصد";
  if (answers.goal === "recomp") estimated = "کم شدن سایز کمر و سفت‌تر شدن عضله بدون نوسان شدید وزن";

  return {
    title: `برنامه ${GOAL_FA[answers.goal] ?? "اختصاصی"}`,
    subtitle: `${SPLIT_NAME[split.key] ?? "اسپلیت سفارشی"} · ${trainDays} جلسه در هفته · ${answers.duration} دقیقه`,
    weeks: 4,
    daysPerWeek: trainDays,
    split: SPLIT_NAME[split.key] ?? split.key,
    goal: answers.goal,
    goalFa: GOAL_FA[answers.goal] ?? answers.goal,
    bmi,
    bmiLabel: bmiLabel(bmi),
    height,
    weight,
    estimatedChange: estimated,
    nutritionTips,
    rules,
    days,
    createdAt: new Date().toISOString(),
  };
}

export const FREE_SESSION: PlannedDay = {
  index: -1,
  week: 0,
  title: "جلسه آشنایی فُرجا",
  focus: "فعال‌سازی کل بدن",
  isRest: false,
  durationMin: 18,
  calories: 140,
  coachNote: "این یک نمونه کوتاه از مربی فُرجا است. بعد از اشتراک، برنامه ۴ هفته‌ای کاملاً شخصی می‌گیری.",
  warmup: ["چرخش شانه و لگن", "۱۰ اسکوات هوایی آرام"],
  exercises: ["bw_squat", "pushup", "band_row", "plank", "bridge"]
    .map((id) => EXERCISES.find((e) => e.id === id))
    .filter((e): e is Exercise => Boolean(e))
    .map((e) =>
      toPlanned(e, 2, e.defaultReps, 40, 6, "نسخه رایگان آشنایی. روی فرم تمرکز کن."),
    ),
  cooldown: ["کشش سینه روی چارچوب در", "نفس عمیق"],
};
