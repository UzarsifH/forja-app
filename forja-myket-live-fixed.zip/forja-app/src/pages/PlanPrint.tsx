import { useEffect, useRef, useState } from "react";
import { apiFetch } from "@/lib/api";
import { exportPlanPdf } from "@/lib/pdf";
import { useRouter } from "@/lib/nav";
import type { WorkoutPlanData } from "@/lib/types";
import { faNum } from "@/lib/format";

export default function PrintPlanPage() {
  const router = useRouter();
  const sheetRef = useRef<HTMLDivElement>(null);
  const [plan, setPlan] = useState<WorkoutPlanData | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    void apiFetch("/api/plan")
      .then((r) => r.json())
      .then((d) => setPlan(d.plan ?? null))
      .finally(() => setLoaded(true));
  }, []);

  async function download() {
    if (!sheetRef.current) return;
    setBusy(true);
    setError("");
    try {
      await exportPlanPdf(sheetRef.current, "forja-plan.pdf");
    } catch (e) {
      console.error(e);
      setError("ساخت PDF انجام نشد. دوباره امتحان کن.");
    } finally {
      setBusy(false);
    }
  }

  if (!plan) {
    return (
      <div className="ps-page">
        <div className="ps-empty">
          {loaded ? "هنوز برنامه‌ای نیست." : "در حال آماده‌سازی برگه برنامه..."}
          {loaded ? (
            <div className="mt-4">
              <button className="ps-btn ps-btn-ghost" onClick={() => router.back()}>
                بازگشت
              </button>
            </div>
          ) : null}
        </div>
      </div>
    );
  }

  return (
    <div className="ps-page" dir="rtl">
      <div className="ps-actions no-print">
        <button className="ps-btn ps-btn-dark" disabled={busy} onClick={() => void download()}>
          {busy ? "در حال ساخت PDF..." : "دانلود / اشتراک PDF"}
        </button>
        <button className="ps-btn ps-btn-ghost" onClick={() => router.back()}>
          بازگشت
        </button>
      </div>
      {error ? <p className="ps-error no-print">{error}</p> : null}

      <div ref={sheetRef} className="ps-sheet">
        <header data-pdf-block className="ps-header">
          <p className="ps-kicker">FORJA COACHING SYSTEM</p>
          <h1 className="ps-title">{plan.title}</h1>
          <p className="ps-sub">{plan.subtitle}</p>
          <div className="ps-meta">
            <span>قد {faNum(plan.height)} سم</span>
            <span>وزن {faNum(plan.weight)} کیلو</span>
            <span>
              BMI {faNum(plan.bmi)} · {plan.bmiLabel}
            </span>
          </div>
        </header>

        <section data-pdf-block className="ps-grid2">
          <div className="ps-box">
            <h2>هدف و مسیر</h2>
            <p>{plan.estimatedChange}</p>
            <p>اسپلیت: {plan.split}</p>
          </div>
          <div className="ps-box">
            <h2>قوانین</h2>
            <ul>
              {plan.rules.map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
          </div>
        </section>

        <section data-pdf-block className="ps-box">
          <h2>تغذیه مربی</h2>
          <ul>
            {plan.nutritionTips.map((r) => (
              <li key={r}>{r}</li>
            ))}
          </ul>
        </section>

        {plan.days.map((d) => (
          <section data-pdf-block key={d.index} className="ps-day">
            <div className="ps-day-head">
              <strong>{d.title}</strong>
              <span>{d.isRest ? "ریکاوری" : `${faNum(d.durationMin)} دقیقه · ${faNum(d.calories)} کالری`}</span>
            </div>
            <div className="ps-day-body">
              <p className="ps-note">{d.coachNote}</p>
              {d.isRest ? (
                <ul>
                  {d.cooldown.map((c) => (
                    <li key={c}>{c}</li>
                  ))}
                </ul>
              ) : (
                <table>
                  <thead>
                    <tr>
                      <th>حرکت</th>
                      <th>عضله</th>
                      <th>ست</th>
                      <th>تکرار</th>
                      <th>استراحت</th>
                      <th>RPE</th>
                    </tr>
                  </thead>
                  <tbody>
                    {d.exercises.map((e) => (
                      <tr key={e.id}>
                        <td className="ps-strong">{e.nameFa}</td>
                        <td>{e.muscleFa}</td>
                        <td>{faNum(e.sets)}</td>
                        <td>{e.reps}</td>
                        <td>{faNum(e.restSec)}s</td>
                        <td>{faNum(e.rpe)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </section>
        ))}

        <footer data-pdf-block className="ps-footer">
          فُرجا · برنامه محرمانه برای این ورزشکار · {faNum(new Date().toLocaleDateString("fa-IR"))}
        </footer>
      </div>
    </div>
  );
}
