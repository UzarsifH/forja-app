import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="grid min-h-[70vh] place-items-center p-8 text-center">
      <div>
        <p className="text-[var(--lime)]">۴۰۴</p>
        <h1 className="mt-2 text-2xl font-extrabold">این مسیر ساخته نشده</h1>
        <Link to="/home" className="mt-4 inline-block text-sm text-white/60">
          برگشت به خانه
        </Link>
      </div>
    </div>
  );
}
