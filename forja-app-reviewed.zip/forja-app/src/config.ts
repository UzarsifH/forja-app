/**
 * تنظیمات اصلی اپ فُرجا
 * (قبلاً این مقادیر در دیتابیس / پنل ادمین بود؛ حالا اینجا ثابت‌اند.)
 */
export const APP_CONFIG = {
  appName: "فُرجا",
  /** باید با appId داخل capacitor.config.json و پنل مایکت یکی باشد */
  packageName: "ir.forja.app",
  /** قیمت اشتراک ماهانه (تومان) */
  monthlyPrice: 249000,
  /** شناسه‌ی محصول (SKU) اشتراک ماهانه در پنل مایکت */
  sku: "premium_monthly",
  /**
   * "sandbox" = خرید آزمایشی؛ اشتراک بدون پرداخت واقعی فعال می‌شود (برای تست).
   * "live"    = فقط وقتی پرداخت واقعی مایکت (MyketBridge) داخل اپ وصل باشد.
   *             راهنما: README.md بخش «پرداخت مایکت»
   */
  paymentMode: "sandbox" as "sandbox" | "live",
  /** کلید RSA عمومی پنل مایکت (برای حالت live) */
  rsaPublicKey: "",
  /** مدت اعتبار هر اشتراک (روز) */
  subscriptionDays: 30,
};
