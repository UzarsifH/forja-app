/**
 * اتصال پرداخت درون‌برنامه‌ای مایکت (IAB)
 *
 * مقادیر را از پنل توسعه‌دهندگان مایکت بردار و در تنظیمات ادمین یا .env بگذار:
 * - MYKET_PACKAGE_NAME     مثل ir.yourapp.package
 * - MYKET_RSA_PUBLIC_KEY   کلید RSA عمومی پنل
 * - MYKET_SKU_MONTHLY      شناسه محصول اشتراک ماهانه
 * - MYKET_ACCESS_TOKEN     در صورت استفاده از وب‌سرویس اعتبارسنجی
 *
 * در نسخه اندروید/وب‌ویو، بریج جاوااسکریپت این متدها را صدا می‌زند:
 *   window.MyketBridge.purchase(sku, payload)
 *   window.onMyketPurchaseSuccess(json)
 *   window.onMyketPurchaseError(message)
 */

export type MyketConfig = {
  packageName: string;
  rsaPublicKey: string;
  skuMonthly: string;
  accessToken: string;
  paymentMode: "sandbox" | "live";
};

export type MyketPurchase = {
  orderId?: string;
  packageName?: string;
  productId?: string;
  purchaseTime?: number;
  purchaseState?: number;
  developerPayload?: string;
  purchaseToken?: string;
  sku?: string;
};

declare global {
  interface Window {
    MyketBridge?: {
      purchase: (sku: string, payload: string) => void;
      init?: (rsaKey: string) => void;
    };
    Android?: {
      purchase?: (sku: string, payload: string) => void;
    };
    onMyketPurchaseSuccess?: (json: string | MyketPurchase) => void;
    onMyketPurchaseError?: (message: string) => void;
  }
}

export function hasNativeMyket() {
  if (typeof window === "undefined") return false;
  return Boolean(window.MyketBridge?.purchase || window.Android?.purchase);
}

export function launchMyketPurchase(sku: string, payload: string) {
  if (typeof window === "undefined") return false;
  if (window.MyketBridge?.purchase) {
    window.MyketBridge.purchase(sku, payload);
    return true;
  }
  if (window.Android?.purchase) {
    window.Android.purchase(sku, payload);
    return true;
  }
  return false;
}

export function parsePurchase(raw: string | MyketPurchase): MyketPurchase {
  if (typeof raw === "string") {
    try {
      return JSON.parse(raw) as MyketPurchase;
    } catch {
      return { purchaseToken: raw };
    }
  }
  return raw;
}
