import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { RippleButton, useAuth } from "@/components/Providers";
import { formatToman } from "@/lib/format";
import { hasNativeMyket, launchMyketPurchase, parsePurchase, type MyketPurchase } from "@/lib/myket";

type Init = {
  paymentId: number;
  amount: number;
  sku: string;
  payload: string;
  packageName: string;
  rsaPublicKey: string;
  paymentMode: string;
};

export default function PayPage() {
  const { user, loading, refresh } = useAuth();
  const router = useRouter();
  const [init, setInit] = useState<Init | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [native, setNative] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    setNative(hasNativeMyket());
    void apiFetch("/api/payment/myket/init", { method: "POST" })
      .then((r) => r.json())
      .then((d) => {
        if (!d.ok) setError(d.error || "خطا در شروع پرداخت");
        else setInit(d as Init);
      });
  }, []);

  useEffect(() => {
    window.onMyketPurchaseSuccess = (json) => {
      void verify(parsePurchase(json));
    };
    window.onMyketPurchaseError = (message) => setError(message);
    return () => {
      window.onMyketPurchaseSuccess = undefined;
      window.onMyketPurchaseError = undefined;
    };
  });

  async function verify(purchase?: MyketPurchase) {
    if (!init) return;
    setBusy(true);
    const res = await apiFetch("/api/payment/myket/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ paymentId: init.paymentId, purchase, sandbox: init.paymentMode !== "live" }),
    });
    const data = await res.json();
    setBusy(false);
    if (!data.ok) {
      setError(data.error || "تأیید ناموفق");
      return;
    }
    await refresh();
    router.replace("/assess");
  }

  function pay() {
    if (!init) return;
    setError("");
    if (init.paymentMode === "live" && launchMyketPurchase(init.sku, init.payload)) return;
    if (native) {
      launchMyketPurchase(init.sku, init.payload);
      return;
    }
    if (init.paymentMode === "live" && !init.rsaPublicKey) {
      setError("کلید RSA مایکت هنوز در پنل ادمین ست نشده.");
      return;
    }
    void verify({
      sku: init.sku,
      productId: init.sku,
      developerPayload: init.payload,
      purchaseToken: `web-${init.paymentId}`,
      orderId: `MYKET-WEB-${init.paymentId}`,
      packageName: init.packageName,
    });
  }

  return (
    <div className="px-5 pt-10">
      <button className="text-sm text-white/50" onClick={() => router.back()}>
        بازگشت
      </button>
      <div className="card mt-5 overflow-hidden">
        <div className="bg-[#0b1b12] p-5">
          <p className="text-xs text-[#9be15d]">درگاه پرداخت درون‌برنامه‌ای مایکت</p>
          <h1 className="mt-2 text-2xl font-extrabold">Myket IAB</h1>
          <p className="mt-1 text-[11px] text-white/50">
            SKU از پنل توسعه‌دهندگان · RSA و Package Name را در ادمین وارد کن
          </p>
        </div>
        <div className="p-5">
          {init ? (
            <>
              <Row k="محصول" v="اشتراک ماهانه فُرجا" />
              <Row k="SKU" v={init.sku} />
              <Row k="پکیج" v={init.packageName || "ir.forja.app"} />
              <Row k="مبلغ" v={formatToman(init.amount)} />
              <Row k="حالت" v={init.paymentMode === "live" ? "زنده" : "آزمایشی / وب‌ویو"} />
              <Row k="Payload" v={init.payload.slice(0, 22) + "…"} />
            </>
          ) : (
            <p className="text-sm text-[var(--muted)]">در حال اتصال به مایکت...</p>
          )}
          {error ? <p className="mt-3 text-sm text-[var(--danger)]">{error}</p> : null}
          <RippleButton className="btn-lime btn-full mt-5" disabled={!init || busy} onClick={pay}>
            {busy ? "در حال تأیید..." : native ? "پرداخت در مایکت" : "ادامه پرداخت مایکت"}
          </RippleButton>
          <p className="mt-3 text-[11px] leading-6 text-white/40">
            اگر اپ داخل وب‌ویو مایکت باشد، بریج `MyketBridge.purchase` صدا زده می‌شود. کلید RSA، توکن و SKU را بعداً از پنل مایکت در تنظیمات ادمین بگذار.
          </p>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between border-b border-white/5 py-2 text-xs">
      <span className="text-white/40">{k}</span>
      <span className="font-bold">{v}</span>
    </div>
  );
}
