/**
 * تنظیمات اصلی اپ فُرجا
 * (قبلاً این مقادیر در دیتابیس / پنل ادمین بود؛ حالا اینجا ثابت‌اند.)
 */
export const APP_CONFIG = {
  appName: "فُرجا",
  /** باید با appId داخل capacitor.config.json و پنل مایکت یکی باشد */
  packageName: "ir.forja.app",
  /** قیمت اشتراک ماهانه (تومان) */
  monthlyPrice: 249000,
  /** شناسه‌ی محصول (SKU) اشتراک ماهانه در پنل مایکت */
  sku: "M1",
  /** پرداخت فقط در حالت واقعی مایکت انجام می‌شود؛ حالت آزمایشی عمداً غیرفعال است. */
  paymentMode: "live" as "sandbox" | "live",
  /** کلید RSA عمومی پنل مایکت (برای حالت live) */
  rsaPublicKey: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCsTEzkrqJlStuC7sasRgv17Qu/inbgdd5C021qS8nSCxb8XTXov6g5x119gPmKUM2zMrKlqIlXtXqOraV04RXbNMj9/D8E643NQYjEvZveUAUOYPqdRMmjie73D8FAzc095SvuWRV6FOJkecEX/CtVflT/VC9jWwYVuLcjIOkrHwIDAQAB",
  /** شناسه/توکن دریافت‌شده از پنل مایکت؛ برای مرجع نگه‌داری شده و نباید مبنای فعال‌سازی محلی باشد. */
  myketAccessToken: "ed094228-0fdd-4274-8d8e-d1d84c5011c5",
  /** مدت اعتبار هر اشتراک (روز) */
  subscriptionDays: 30,
};
