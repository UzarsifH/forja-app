/**
 * پرداخت واقعی مایکت برای نسخه Android.
 *
 * این فایل عمداً هیچ fallback یا رسید ساختگی ندارد:
 * اگر مایکت/SDK در دسترس نباشد، خرید ناموفق است و اشتراک فعال نمی‌شود.
 */
import { Capacitor } from "@capacitor/core";
import { Myket } from "@salarizadi/capacitor-myket";
import { APP_CONFIG } from "@/config";

export type MyketPurchase = {
  orderId?: string;
  packageName?: string;
  productId?: string;
  purchaseTime?: number;
  purchaseState?: number | string;
  developerPayload?: string;
  purchaseToken?: string;
  sku?: string;
  signature?: string;
  [key: string]: unknown;
};

export function hasNativeMyket() {
  return Capacitor.getPlatform() === "android";
}

export async function initializeMyket() {
  if (!hasNativeMyket()) return false;
  const result = await Myket.initialize({ rsaPublicKey: APP_CONFIG.rsaPublicKey });
  if (!result.connected) throw new Error("اتصال به مایکت برقرار نشد.");

  // وجود محصول در پنل مایکت را قبل از شروع خرید بررسی می‌کنیم.
  const catalog = await Myket.getProducts({ skus: [APP_CONFIG.sku] });
  if (!catalog.products?.some((p: { sku?: string }) => p.sku === APP_CONFIG.sku)) {
    throw new Error(`محصول ${APP_CONFIG.sku} در مایکت پیدا نشد یا فعال نیست.`);
  }
  return true;
}

export async function launchMyketPurchase(sku: string, payload: string): Promise<MyketPurchase> {
  if (!hasNativeMyket()) {
    throw new Error("پرداخت مایکت فقط داخل نسخه Android فُرجا انجام می‌شود.");
  }

  await initializeMyket();
  const result = await Myket.purchaseProduct({
    productId: sku,
    type: "subs",
    payload,
  });

  const purchase = (result?.purchase ?? {}) as MyketPurchase;
  const productId = purchase.productId || purchase.sku;
  const state = String(purchase.purchaseState ?? "").toUpperCase();

  if (productId !== sku) throw new Error("محصول خریداری‌شده با اشتراک فُرجا یکی نیست.");
  if (!purchase.purchaseToken) throw new Error("مایکت رسید خرید معتبری برنگرداند.");
  if (state && !["PURCHASED", "0"].includes(state)) {
    throw new Error("خرید توسط مایکت تأیید نشد.");
  }

  return purchase;
}

export function parsePurchase(raw: string | MyketPurchase): MyketPurchase {
  if (typeof raw === "string") {
    try {
      return JSON.parse(raw) as MyketPurchase;
    } catch {
      return { purchaseToken: raw };
    }
  }
  return raw;
}
